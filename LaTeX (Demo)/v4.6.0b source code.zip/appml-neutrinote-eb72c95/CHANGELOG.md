
See fastlane/metadata/android/en-US/changelogs/ for individual changes for each version.
