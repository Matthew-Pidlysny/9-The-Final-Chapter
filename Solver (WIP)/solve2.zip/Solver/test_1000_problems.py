#!/usr/bin/env python3
"""
SOLVER Testing Framework - 1000 Unsolved Problems Challenge
============================================================

Comprehensive testing suite to validate solver capabilities across
all mathematical domains and identify areas for enhancement.

Problem Categories:
1. Foundations (100 problems)
2. Number Theory (150 problems)
3. Algebra (150 problems)
4. Analysis (100 problems)
5. Geometry (100 problems)
6. Topology (50 problems)
7. Combinatorics (100 problems)
8. Probability (100 problems)
9. Physics (100 problems)
10. Computational (50 problems)
11. Advanced/Millennium (50 problems)
12. Formula Patterns (50 problems - new)
13. Zero Proof Journey (50 problems - bonus)
"""

import sys
import random
import time
import json
from pathlib import Path
from typing import Dict, List, Any, Tuple
import numpy as np
from sympy import symbols, expand, factor, simplify, solve, diff, integrate, limit, oo, pi, E, I
from sympy import prime, primerange, isprime, fibonacci, factorial, binomial, bernoulli

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from workshops import *

class ProblemGenerator:
    """Generate diverse mathematical problems for testing"""
    
    def __init__(self):
        self.primes = list(primerange(2, 1000))
    
    def generate_foundations_problems(self, n: int = 100) -> List[Dict]:
        """Generate foundation problems"""
        problems = []
        
        # Number classification
        for i in range(20):
            num = random.randint(-100, 100)
            problems.append({
                'type': 'classification',
                'question': f'Classify {num}: natural, integer, rational, irrational, real, complex?',
                'category': 'foundations',
                'difficulty': 'easy'
            })
        
        # Prime testing
        for i in range(20):
            num = random.choice(self.primes + [random.randint(2, 1000)])
            problems.append({
                'type': 'prime_test',
                'question': f'Is {num} prime?',
                'category': 'foundations',
                'expected': isprime(num),
                'difficulty': 'easy'
            })
        
        # Factorization
        for i in range(20):
            num = random.randint(2, 1000)
            problems.append({
                'type': 'factorization',
                'question': f'Find prime factors of {num}',
                'category': 'foundations',
                'difficulty': 'medium'
            })
        
        # GCD and LCM
        for i in range(20):
            a, b = random.randint(2, 100), random.randint(2, 100)
            problems.append({
                'type': 'gcd_lcm',
                'question': f'Find GCD and LCM of {a} and {b}',
                'category': 'foundations',
                'difficulty': 'easy'
            })
        
        # Special sequences
        sequences = ['fibonacci', 'catalan', 'bell', 'partition']
        for i in range(20):
            seq = random.choice(sequences)
            n = random.randint(1, 20)
            problems.append({
                'type': 'sequence',
                'question': f'Find the {n}th {seq} number',
                'category': 'foundations',
                'difficulty': 'medium'
            })
        
        return problems
    
    def generate_number_theory_problems(self, n: int = 150) -> List[Dict]:
        """Generate number theory problems including Collatz, Riemann, Goldbach"""
        problems = []
        
        # Collatz sequences
        for i in range(50):
            start = random.randint(1, 100)
            problems.append({
                'type': 'collatz',
                'question': f'Find Collatz sequence starting from {start}',
                'category': 'number_theory',
                'difficulty': 'medium'
            })
        
        # Goldbach conjecture
        for i in range(50):
            num = random.choice([even for even in range(4, 101) if even % 2 == 0])
            problems.append({
                'type': 'goldbach',
                'question': f'Express {num} as sum of two primes (Goldbach)',
                'category': 'number_theory',
                'difficulty': 'medium'
            })
        
        # Prime counting
        for i in range(25):
            n = random.randint(10, 1000)
            problems.append({
                'type': 'prime_counting',
                'question': f'Count primes ≤ {n}',
                'category': 'number_theory',
                'difficulty': 'medium'
            })
        
        # Divisor functions
        for i in range(25):
            num = random.randint(1, 500)
            problems.append({
                'type': 'divisor_count',
                'question': f'Find number of divisors of {num}',
                'category': 'number_theory',
                'difficulty': 'easy'
            })
        
        return problems
    
    def generate_algebra_problems(self, n: int = 150) -> List[Dict]:
        """Generate algebra problems"""
        problems = []
        
        # Linear equations
        for i in range(30):
            a, b = random.randint(1, 20), random.randint(1, 100)
            problems.append({
                'type': 'linear_equation',
                'question': f'Solve {a}x + {b} = 0',
                'category': 'algebra',
                'difficulty': 'easy'
            })
        
        # Quadratic equations
        for i in range(30):
            a, b, c = random.randint(1, 10), random.randint(-20, 20), random.randint(-50, 50)
            problems.append({
                'type': 'quadratic',
                'question': f'Solve {a}x² + {b}x + {c} = 0',
                'category': 'algebra',
                'difficulty': 'easy'
            })
        
        # Polynomial operations
        for i in range(30):
            problems.append({
                'type': 'polynomial',
                'question': f'Factor x³ - 6x² + 11x - 6',
                'category': 'algebra',
                'difficulty': 'medium'
            })
        
        # Systems of equations
        for i in range(30):
            a1, b1, c1 = random.randint(1, 10), random.randint(1, 10), random.randint(1, 20)
            a2, b2, c2 = random.randint(1, 10), random.randint(1, 10), random.randint(1, 20)
            problems.append({
                'type': 'system',
                'question': f'Solve: {a1}x + {b1}y = {c1}, {a2}x + {b2}y = {c2}',
                'category': 'algebra',
                'difficulty': 'medium'
            })
        
        # Root finding
        for i in range(30):
            problems.append({
                'type': 'root_finding',
                'question': f'Find roots of x⁵ - 3x³ + 2x - 1 = 0',
                'category': 'algebra',
                'difficulty': 'hard'
            })
        
        return problems
    
    def generate_analysis_problems(self, n: int = 100) -> List[Dict]:
        """Generate calculus and analysis problems"""
        problems = []
        
        # Limits
        for i in range(25):
            problems.append({
                'type': 'limit',
                'question': f'Calculate limit of (sin(x)/x) as x approaches 0',
                'category': 'analysis',
                'difficulty': 'medium'
            })
        
        # Derivatives
        for i in range(25):
            problems.append({
                'type': 'derivative',
                'question': f'Find derivative of x³ - 2x² + 3x - 1',
                'category': 'analysis',
                'difficulty': 'easy'
            })
        
        # Integrals
        for i in range(25):
            problems.append({
                'type': 'integral',
                'question': f'Calculate ∫(x² + 2x + 1)dx',
                'category': 'analysis',
                'difficulty': 'medium'
            })
        
        # Series
        for i in range(25):
            problems.append({
                'type': 'series',
                'question': f'Test convergence of series ∑(1/n²)',
                'category': 'analysis',
                'difficulty': 'medium'
            })
        
        return problems
    
    def generate_geometry_problems(self, n: int = 100) -> List[Dict]:
        """Generate geometry problems"""
        problems = []
        
        # Distance calculations
        for i in range(25):
            problems.append({
                'type': 'distance',
                'question': f'Distance between (0,0) and (3,4)',
                'category': 'geometry',
                'difficulty': 'easy'
            })
        
        # Triangle properties
        for i in range(25):
            problems.append({
                'type': 'triangle',
                'question': f'Find area of triangle with sides 3,4,5',
                'category': 'geometry',
                'difficulty': 'easy'
            })
        
        # Circle properties
        for i in range(25):
            r = random.randint(1, 20)
            problems.append({
                'type': 'circle',
                'question': f'Area and circumference of circle with radius {r}',
                'category': 'geometry',
                'difficulty': 'easy'
            })
        
        # 3D geometry
        for i in range(25):
            problems.append({
                'type': '3d',
                'question': f'Volume of sphere with radius 5',
                'category': 'geometry',
                'difficulty': 'medium'
            })
        
        return problems
    
    def generate_topology_problems(self, n: int = 50) -> List[Dict]:
        """Generate topology problems"""
        problems = []
        
        # Distance metrics
        for i in range(20):
            problems.append({
                'type': 'distance_metric',
                'question': f'Calculate Euclidean, Manhattan, and Chebyshev distances between (1,2,3) and (4,5,6)',
                'category': 'topology',
                'difficulty': 'easy'
            })
        
        # Graph connectivity
        for i in range(15):
            problems.append({
                'type': 'graph_connectivity',
                'question': f'Check if graph is connected',
                'category': 'topology',
                'difficulty': 'medium'
            })
        
        # Euler characteristic
        for i in range(15):
            problems.append({
                'type': 'euler',
                'question': f'Calculate Euler characteristic for a cube (8 vertices, 12 edges, 6 faces)',
                'category': 'topology',
                'difficulty': 'easy'
            })
        
        return problems
    
    def generate_combinatorics_problems(self, n: int = 100) -> List[Dict]:
        """Generate combinatorics problems"""
        problems = []
        
        # Permutations
        for i in range(25):
            n, r = random.randint(5, 10), random.randint(2, 5)
            problems.append({
                'type': 'permutation',
                'question': f'Number of permutations P({n},{r})',
                'category': 'combinatorics',
                'difficulty': 'easy'
            })
        
        # Combinations
        for i in range(25):
            n, r = random.randint(5, 10), random.randint(2, 5)
            problems.append({
                'type': 'combination',
                'question': f'Number of combinations C({n},{r})',
                'category': 'combinatorics',
                'difficulty': 'easy'
            })
        
        # Stirling numbers
        for i in range(25):
            n, k = random.randint(3, 8), random.randint(2, 6)
            problems.append({
                'type': 'stirling',
                'question': f'Stirling number of second kind S({n},{k})',
                'category': 'combinatorics',
                'difficulty': 'medium'
            })
        
        # Catalan numbers
        for i in range(25):
            n = random.randint(1, 10)
            problems.append({
                'type': 'catalan',
                'question': f'Find the {n}th Catalan number',
                'category': 'combinatorics',
                'difficulty': 'medium'
            })
        
        return problems
    
    def generate_probability_problems(self, n: int = 100) -> List[Dict]:
        """Generate probability problems"""
        problems = []
        
        # Binomial distribution
        for i in range(25):
            problems.append({
                'type': 'binomial',
                'question': f'Binomial probability P(X=k) for n=10, p=0.5, k=5',
                'category': 'probability',
                'difficulty': 'medium'
            })
        
        # Normal distribution
        for i in range(25):
            problems.append({
                'type': 'normal',
                'question': f'Normal distribution PDF at x=0 with μ=0, σ=1',
                'category': 'probability',
                'difficulty': 'medium'
            })
        
        # Expected value
        for i in range(25):
            problems.append({
                'type': 'expected',
                'question': f'Expected value of dice roll',
                'category': 'probability',
                'difficulty': 'easy'
            })
        
        # Variance
        for i in range(25):
            problems.append({
                'type': 'variance',
                'question': f'Variance of dice roll',
                'category': 'probability',
                'difficulty': 'easy'
            })
        
        return problems
    
    def generate_physics_problems(self, n: int = 100) -> List[Dict]:
        """Generate physics problems"""
        problems = []
        
        # Kinematics
        for i in range(20):
            problems.append({
                'type': 'kinematics',
                'question': f'Calculate final velocity with v0=10m/s, a=5m/s², t=3s',
                'category': 'physics',
                'difficulty': 'easy'
            })
        
        # Energy
        for i in range(20):
            problems.append({
                'type': 'energy',
                'question': f'Kinetic energy with m=5kg, v=10m/s',
                'category': 'physics',
                'difficulty': 'easy'
            })
        
        # Relativity
        for i in range(20):
            problems.append({
                'type': 'relativity',
                'question': f'Time dilation at v=0.8c',
                'category': 'physics',
                'difficulty': 'hard'
            })
        
        # Quantum
        for i in range(20):
            problems.append({
                'type': 'quantum',
                'question': f'De Broglie wavelength of electron with v=10⁶ m/s',
                'category': 'physics',
                'difficulty': 'hard'
            })
        
        # Electromagnetism
        for i in range(20):
            problems.append({
                'type': 'electromagnetism',
                'question': f'Coulomb force between q1=1μC, q2=2μC at r=1m',
                'category': 'physics',
                'difficulty': 'medium'
            })
        
        return problems
    
    def generate_computational_problems(self, n: int = 50) -> List[Dict]:
        """Generate computational algorithm problems"""
        problems = []
        
        # Sorting
        for i in range(15):
            arr = random.sample(range(1, 101), 10)
            problems.append({
                'type': 'sort',
                'question': f'Sort array: {arr[:5]}...',
                'category': 'computational',
                'difficulty': 'easy'
            })
        
        # Searching
        for i in range(15):
            target = random.randint(1, 100)
            arr = sorted(random.sample(range(1, 101), 10))
            problems.append({
                'type': 'search',
                'question': f'Binary search for {target} in {arr[:5]}...',
                'category': 'computational',
                'difficulty': 'easy'
            })
        
        # Graph algorithms
        for i in range(20):
            problems.append({
                'type': 'graph',
                'question': f'Find shortest path in graph',
                'category': 'computational',
                'difficulty': 'medium'
            })
        
        return problems
    
    def generate_advanced_problems(self, n: int = 50) -> List[Dict]:
        """Generate advanced/millennium problems"""
        problems = []
        
        # P vs NP
        for i in range(10):
            problems.append({
                'type': 'p_vs_np',
                'question': f'Analyze P vs NP problem',
                'category': 'advanced',
                'difficulty': 'hard'
            })
        
        # Riemann Hypothesis
        for i in range(10):
            problems.append({
                'type': 'riemann',
                'question': f'Test Riemann zeta function zeros',
                'category': 'advanced',
                'difficulty': 'hard'
            })
        
        # Perfect numbers
        for i in range(10):
            n = random.choice([6, 28, 496, 8128])
            problems.append({
                'type': 'perfect',
                'question': f'Is {n} a perfect number?',
                'category': 'advanced',
                'difficulty': 'medium'
            })
        
        # Amicable pairs
        for i in range(10):
            problems.append({
                'type': 'amicable',
                'question': f'Find amicable pairs',
                'category': 'advanced',
                'difficulty': 'medium'
            })
        
        # Millennium problems
        for i in range(10):
            problems.append({
                'type': 'millennium',
                'question': f'Analyze Millennium Problem',
                'category': 'advanced',
                'difficulty': 'hard'
            })
        
        return problems
    
    def generate_formula_pattern_problems(self, n: int = 50) -> List[Dict]:
        """Generate problems based on provided formula patterns"""
        problems = []
        
        # Pattern 1: 39 - 18*x = 2Δ
        for i in range(15):
            x = random.randint(1, 10)
            problems.append({
                'type': 'delta_pattern',
                'question': f'Solve for Δ: 39 - 18*{x} = 2Δ',
                'category': 'formula_pattern',
                'pattern': '39 - 18*x = 2Δ',
                'difficulty': 'easy'
            })
        
        # Pattern 2: 2x + 5 - y = 0
        for i in range(15):
            x = random.randint(1, 10)
            problems.append({
                'type': 'linear_pattern',
                'question': f'Solve for y: 2*{x} + 5 - y = 0',
                'category': 'formula_pattern',
                'pattern': '2x + 5 - y = 0',
                'difficulty': 'easy'
            })
        
        # Pattern 3: [Repeating String of 1/13] * Δ_z = Finite Mass
        for i in range(10):
            problems.append({
                'type': 'repeating_pattern',
                'question': f'Analyze: [1/13 repeating] * Δ_z = Finite Mass',
                'category': 'formula_pattern',
                'pattern': 'repeating_string * Δ_z = finite_mass',
                'difficulty': 'hard'
            })
        
        # Pattern 4: Pi * Δ_6 = λ^4
        for i in range(10):
            problems.append({
                'type': 'lambda_pattern',
                'question': f'Analyze: π * Δ_6 = λ^4',
                'category': 'formula_pattern',
                'pattern': 'pi * Δ_6 = λ^4',
                'difficulty': 'hard'
            })
        
        return problems
    
    def generate_zero_proof_problems(self, n: int = 50) -> List[Dict]:
        """Generate zero proof journey problems"""
        problems = []
        
        # Zero properties
        for i in range(10):
            problems.append({
                'type': 'zero_properties',
                'question': f'Analyze: Why does 0 × x = 0?',
                'category': 'zero_proof',
                'difficulty': 'easy'
            })
        
        # Division by zero
        for i in range(10):
            problems.append({
                'type': 'division_by_zero',
                'question': f'Analyze: Why is x/0 undefined?',
                'category': 'zero_proof',
                'difficulty': 'medium'
            })
        
        # Zero in limits
        for i in range(10):
            problems.append({
                'type': 'zero_limits',
                'question': f'Analyze: limit as x approaches 0 of x/x',
                'category': 'zero_proof',
                'difficulty': 'medium'
            })
        
        # Zero power
        for i in range(10):
            problems.append({
                'type': 'zero_power',
                'question': f'Analyze: Why is x^0 = 1 for x ≠ 0?',
                'category': 'zero_proof',
                'difficulty': 'medium'
            })
        
        # Zero as origin
        for i in range(10):
            problems.append({
                'type': 'zero_origin',
                'question': f'Philosophical: Zero as the perfect origin and balance point',
                'category': 'zero_proof',
                'difficulty': 'hard'
            })
        
        return problems


class SolverTester:
    """Test solver against 1000 problems"""
    
    def __init__(self, solver):
        self.solver = solver
        self.generator = ProblemGenerator()
        self.results = {
            'total': 0,
            'solved': 0,
            'failed': 0,
            'by_category': {},
            'errors': []
        }
    
    def run_all_tests(self):
        """Run all 1000 problems"""
        print("=" * 80)
        print("🧪 SOLVER TESTING FRAMEWORK - 1000 PROBLEMS CHALLENGE")
        print("=" * 80)
        print()
        
        # Generate all problems
        all_problems = []
        all_problems.extend(self.generator.generate_foundations_problems(100))
        all_problems.extend(self.generator.generate_number_theory_problems(150))
        all_problems.extend(self.generator.generate_algebra_problems(150))
        all_problems.extend(self.generator.generate_analysis_problems(100))
        all_problems.extend(self.generator.generate_geometry_problems(100))
        all_problems.extend(self.generator.generate_topology_problems(50))
        all_problems.extend(self.generator.generate_combinatorics_problems(100))
        all_problems.extend(self.generator.generate_probability_problems(100))
        all_problems.extend(self.generator.generate_physics_problems(100))
        all_problems.extend(self.generator.generate_computational_problems(50))
        all_problems.extend(self.generator.generate_advanced_problems(50))
        all_problems.extend(self.generator.generate_formula_pattern_problems(50))
        all_problems.extend(self.generator.generate_zero_proof_problems(50))
        
        self.results['total'] = len(all_problems)
        print(f"Generated {self.results['total']} problems")
        print()
        
        # Test each problem
        start_time = time.time()
        for i, problem in enumerate(all_problems, 1):
            self.test_problem(problem, i)
        
        elapsed_time = time.time() - start_time
        
        # Print summary
        self.print_summary(elapsed_time)
        
        return self.results
    
    def test_problem(self, problem: Dict, index: int):
        """Test a single problem"""
        category = problem['category']
        question = problem['question']
        
        if category not in self.results['by_category']:
            self.results['by_category'][category] = {
                'total': 0,
                'solved': 0,
                'failed': 0
            }
        
        self.results['by_category'][category]['total'] += 1
        
        try:
            # Attempt to solve
            result = self.solver.solve(question, problem_type=category)
            
            if result.get('success', False):
                self.results['solved'] += 1
                self.results['by_category'][category]['solved'] += 1
                print(f"✅ [{index}] {category}: Solved")
            else:
                self.results['failed'] += 1
                self.results['by_category'][category]['failed'] += 1
                print(f"❌ [{index}] {category}: Failed - {result.get('message', 'No solution')}")
        except Exception as e:
            self.results['failed'] += 1
            self.results['by_category'][category]['failed'] += 1
            self.results['errors'].append({
                'index': index,
                'problem': problem,
                'error': str(e)
            })
            print(f"⚠️  [{index}] {category}: Error - {str(e)[:50]}")
    
    def print_summary(self, elapsed_time: float):
        """Print test summary"""
        print()
        print("=" * 80)
        print("📊 TEST SUMMARY")
        print("=" * 80)
        print(f"Total Problems: {self.results['total']}")
        print(f"Solved: {self.results['solved']} ({self.results['solved']/self.results['total']*100:.1f}%)")
        print(f"Failed: {self.results['failed']} ({self.results['failed']/self.results['total']*100:.1f}%)")
        print(f"Time Elapsed: {elapsed_time:.2f} seconds")
        print()
        
        print("Results by Category:")
        print("-" * 80)
        for category, stats in sorted(self.results['by_category'].items()):
            total = stats['total']
            solved = stats['solved']
            failed = stats['failed']
            print(f"{category:20s}: {solved:4d}/{total:4d} ({solved/total*100:5.1f}%)")
        
        print()
        if self.results['errors']:
            print(f"Errors: {len(self.results['errors'])}")
            for error in self.results['errors'][:10]:
                print(f"  - Problem {error['index']}: {error['error'][:50]}")


def main():
    """Main test runner"""
    # Initialize solver
    from main import Solver
    solver = Solver()
    
    # Run tests
    tester = SolverTester(solver)
    results = tester.run_all_tests()
    
    # Save results
    with open('/workspace/test_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print()
    print(f"Results saved to: /workspace/test_results.json")


if __name__ == "__main__":
    main()