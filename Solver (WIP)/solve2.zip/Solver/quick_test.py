#!/usr/bin/env python3
"""Quick test of a few representative problems"""

from main import Solver

solver = Solver()

test_problems = [
    # Foundations
    ('Classify 15: natural, integer, rational, irrational, real, complex?', 'foundations'),
    ('Is 997 prime?', 'number_theory'),
    ('Find prime factors of 123456', 'foundations'),
    ('Find GCD and LCM of 48 and 18', 'foundations'),
    
    # Number Theory
    ('Find Collatz sequence starting from 27', 'number_theory'),
    ('Express 100 as sum of two primes (Goldbach)', 'number_theory'),
    ('Count primes ≤ 100', 'number_theory'),
    
    # Algebra
    ('Solve 3x + 5 = 0', 'algebra'),
    ('Solve 2x² + 5x + 3 = 0', 'algebra'),
    ('Solve: 2x + 3y = 7, 3x + 2y = 8', 'algebra'),
    
    # Analysis
    ('Calculate limit of (sin(x)/x) as x approaches 0', 'analysis'),
    ('Find derivative of x³ - 2x² + 3x - 1', 'analysis'),
    ('Calculate ∫(x² + 2x + 1)dx', 'analysis'),
    
    # Geometry
    ('Distance between (0,0) and (3,4)', 'geometry'),
    ('Find area of triangle with sides 3,4,5', 'geometry'),
    ('Area and circumference of circle with radius 5', 'geometry'),
    
    # Topology
    ('Calculate Euclidean, Manhattan, and Chebyshev distances between (1,2,3) and (4,5,6)', 'topology'),
    
    # Combinatorics
    ('Number of permutations P(5,3)', 'combinatorics'),
    ('Number of combinations C(5,3)', 'combinatorics'),
    ('Find the 5th Catalan number', 'combinatorics'),
    
    # Probability
    ('Expected value of dice roll', 'probability'),
    ('Variance of dice roll', 'probability'),
    
    # Physics
    ('Calculate final velocity with v0=10m/s, a=5m/s², t=3s', 'physics'),
    ('Kinetic energy with m=5kg, v=10m/s', 'physics'),
    
    # Computational
    ('Binary search for 50 in sorted array', 'computational'),
    
    # Advanced
    ('Is 6 a perfect number?', 'advanced'),
    
    # Formula Patterns
    ('Solve for Δ: 39 - 18*2 = 2Δ', 'formula_pattern'),
    ('Solve for y: 2*5 + 5 - y = 0', 'formula_pattern'),
]

print("=" * 80)
print("QUICK TEST - Representative Problems")
print("=" * 80)

results_by_category = {}
total = len(test_problems)
solved = 0

for question, category in test_problems:
    result = solver.solve(question, problem_type=category)
    
    if category not in results_by_category:
        results_by_category[category] = {'total': 0, 'solved': 0}
    
    results_by_category[category]['total'] += 1
    
    if result['success']:
        solved += 1
        results_by_category[category]['solved'] += 1
        print(f"✅ {category:20s}: {question[:50]}")
    else:
        print(f"❌ {category:20s}: {question[:50]}")
        print(f"   Error: {result['solution'].get('error', 'No solution')[:60]}")

print()
print("=" * 80)
print("SUMMARY")
print("=" * 80)
print(f"Total: {solved}/{total} ({solved/total*100:.1f}%)")
print()
print("By Category:")
for cat, stats in sorted(results_by_category.items()):
    print(f"  {cat:20s}: {stats['solved']}/{stats['total']} ({stats['solved']/stats['total']*100:.1f}%)")