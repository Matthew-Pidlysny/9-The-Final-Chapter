"""
Formula Preview Panel for Peer System
Renders formula previews without modifying original code
"""
import re
from typing import Optional


class FormulaPreviewPanel:
    """
    Renders formula previews in various formats
    """
    
    def __init__(self):
        """Initialize preview panel"""
        self.renderers = {
            'latex': self._render_latex,
            'text': self._render_text,
            'html': self._render_html,
        }
    
    def render(self, formula: str, format: str = 'latex') -> str:
        """
        Render formula in specified format
        
        Args:
            formula: The formula string
            format: Output format ('latex', 'text', 'html')
            
        Returns:
            Rendered formula string
        """
        renderer = self.renderers.get(format, self._render_text)
        return renderer(formula)
    
    def _render_latex(self, formula: str) -> str:
        """Render formula as LaTeX"""
        # Convert common symbols to LaTeX
        latex_formula = formula
        
        # Mathematical operators
        latex_formula = latex_formula.replace('∫', r'\int')
        latex_formula = latex_formula.replace('∂', r'\partial')
        latex_formula = latex_formula.replace('√', r'\sqrt')
        latex_formula = latex_formula.replace('∞', r'\infty')
        latex_formula = latex_formula.replace('±', r'\pm')
        latex_formula = latex_formula.replace('≠', r'\neq')
        latex_formula = latex_formula.replace('≈', r'\approx')
        latex_formula = latex_formula.replace('≤', r'\leq')
        latex_formula = latex_formula.replace('≥', r'\geq')
        latex_formula = latex_formula.replace('→', r'\rightarrow')
        latex_formula = latex_formula.replace('←', r'\leftarrow')
        
        # Greek letters
        greek = {
            'α': r'\alpha', 'β': r'\beta', 'γ': r'\gamma', 'δ': r'\delta',
            'ε': r'\epsilon', 'ζ': r'\zeta', 'η': r'\eta', 'θ': r'\theta',
            'ι': r'\iota', 'κ': r'\kappa', 'λ': r'\lambda', 'μ': r'\mu',
            'ν': r'\nu', 'ξ': r'\xi', 'π': r'\pi', 'ρ': r'\rho',
            'σ': r'\sigma', 'τ': r'\tau', 'υ': r'\upsilon', 'φ': r'\phi',
            'χ': r'\chi', 'ψ': r'\psi', 'ω': r'\omega',
        }
        
        for char, latex in greek.items():
            latex_formula = latex_formula.replace(char, latex)
        
        # Superscripts and subscripts
        latex_formula = re.sub(r'([a-zA-Z0-9]+)²', r'\1^2', latex_formula)
        latex_formula = re.sub(r'([a-zA-Z0-9]+)³', r'\1^3', latex_formula)
        latex_formula = re.sub(r'\^', r'^', latex_formula)
        
        return f"${latex_formula}$"
    
    def _render_text(self, formula: str) -> str:
        """Render formula as plain text"""
        return formula
    
    def _render_html(self, formula: str) -> str:
        """Render formula as HTML"""
        # Basic HTML formatting
        html_formula = formula
        
        # Superscripts
        html_formula = re.sub(r'([a-zA-Z0-9]+)²', r'\1<sup>2</sup>', html_formula)
        html_formula = re.sub(r'([a-zA-Z0-9]+)³', r'\1<sup>3</sup>', html_formula)
        html_formula = re.sub(r'\^(\d+)', r'<sup>\1</sup>', html_formula)
        
        # Subscripts
        html_formula = re.sub(r'([a-zA-Z])_([a-zA-Z0-9]+)', r'\1<sub>\2</sub>', html_formula)
        
        # Greek letters
        greek_html = {
            'α': '&alpha;', 'β': '&beta;', 'γ': '&gamma;', 'δ': '&delta;',
            'ε': '&epsilon;', 'ζ': '&zeta;', 'η': '&eta;', 'θ': '&theta;',
            'μ': '&mu;', 'π': '&pi;', 'σ': '&sigma;',
        }
        
        for char, html in greek_html.items():
            html_formula = html_formula.replace(char, html)
        
        return html_formula
    
    def get_rendered_preview(self, formula: str, max_length: int = 100) -> str:
        """
        Get a short preview of rendered formula
        
        Args:
            formula: The formula string
            max_length: Maximum length of preview
            
        Returns:
            Short preview string
        """
        if len(formula) <= max_length:
            return self.render(formula, 'text')
        
        return self.render(formula[:max_length-3], 'text') + "..."


if __name__ == "__main__":
    panel = FormulaPreviewPanel()
    
    test_formulas = [
        "E = mc²",
        "∫ x² dx",
        "F = ma",
        "μ = Σx/n",
        "PV = nRT",
    ]
    
    print("Formula Preview Panel Test")
    print("=" * 60)
    
    for formula in test_formulas:
        print(f"\nOriginal: {formula}")
        print(f"LaTeX:    {panel.render(formula, 'latex')}")
        print(f"HTML:     {panel.render(formula, 'html')}")