"""
Scientific Improvements Lookup System
Provides context-aware scientific suggestions for formula validation
"""
import re
from typing import List, Dict, Tuple, Optional
from enum import Enum

class ScientificDomain(Enum):
    """Categories of scientific domains"""
    MATHEMATICS = "Mathematics"
    PHYSICS = "Physics"
    CHEMISTRY = "Chemistry"
    BIOLOGY = "Biology"
    ENGINEERING = "Engineering"
    COMPUTER_SCIENCE = "Computer Science"
    BIOPHYSICS = "Biophysics"
    COMPUTATIONAL_MATH = "Computational Mathematics"
    DATA_SCIENCE = "Data Science"
    FINANCIAL_MATH = "Financial Mathematics"
    ENVIRONMENTAL = "Environmental Science"
    NEUROSCIENCE = "Neuroscience"
    CONDENSED_MATTER = "Condensed Matter Physics"
    PARTICLE_PHYSICS = "Particle Physics"
    ASTROPHYSICS = "Astrophysics"
    OPTICS = "Optics and Photonics"


class ScientificImprovementEngine:
    """
    Engine for providing scientific improvements and suggestions
    based on formula content and context
    """
    
    def __init__(self):
        """Initialize the improvement engine"""
        self.patterns = self._build_patterns()
        self.improvements_db = self._load_improvements()
    
    def _build_patterns(self) -> Dict[str, List[str]]:
        """Build regex patterns for detecting scientific concepts"""
        return {
            'calculus': [
                r'\b(d/d[a-z])\b',
                r'\bintegral\b',
                r'\bderivative\b',
                r'\b∂\b',
                r'∫',
            ],
            'algebra': [
                r'\b([a-z]\^?\d*)\s*=\s*',
                r'\b(equation)\b',
                r'\b(solve)\b',
                r'\b(root)\b',
            ],
            'geometry': [
                r'\b(triangle|circle|square|rectangle)\b',
                r'\b(area|perimeter|volume)\b',
                r'\b(Pythagorean)\b',
                r'π|pi',
            ],
            'statistics': [
                r'\b(mean|median|mode|std|variance)\b',
                r'\b(correlation|regression)\b',
                r'\b(probability|p-value)\b',
                r'\b(distribution)\b',
            ],
            'physics': [
                r'\b(F=ma|E=mc²)\b',
                r'\b(force|energy|power)\b',
                r'\b(velocity|acceleration)\b',
                r'\b(quantum|relativity)\b',
            ],
            'chemistry': [
                r'\b(molar|stoichiometry)\b',
                r'\b(pH|acid|base)\b',
                r'\b(reaction|equilibrium)\b',
                r'\b(Avogadro)\b',
            ],
            'thermodynamics': [
                r'\b(entropy|enthalpy|Gibbs)\b',
                r'\b(heat|temperature)\b',
                r'\b(adiabatic|isothermal)\b',
                r'\b(Kelvin|Celsius|Fahrenheit)\b',
            ],
            'electromagnetism': [
                r'\b(Ohm|voltage|current)\b',
                r'\b(magnetic|electric)\b',
                r'\b(Maxwell|Faraday)\b',
                r'\b(circuit|resistance)\b',
            ],
            'quantum': [
                r'\b(Schrödinger|Heisenberg)\b',
                r'\b(wave function|eigenvalue)\b',
                r'\b(uncertainty|tunneling)\b',
                r'\b(ℏ|h-bar)\b',
            ],
            'relativity': [
                r'\b(Lorentz|Einstein)\b',
                r'\b(time dilation|length contraction)\b',
                r'\b(spacetime|metric)\b',
                r'\b(black hole|event horizon)\b',
            ],
            'biology': [
                r'\b(DNA|RNA|protein)\b',
                r'\b(cell|organism)\b',
                r'\b(genetics|mutation)\b',
                r'\b(evolution|population)\b',
            ],
            'neuroscience': [
                r'\b(neuron|synapse|brain)\b',
                r'\b(action potential|neurotransmitter)\b',
                r'\b(fMRI|EEG)\b',
                r'\b(plasticity|memory)\b',
            ],
        }
    
    def _load_improvements(self) -> Dict[str, List[Dict]]:
        """
        Load scientific improvements by category
        Returns structured improvement suggestions
        """
        return {
            'calculus': [
                {
                    'issue': 'Integration constant',
                    'suggestion': 'Remember to include the constant of integration (+ C) when evaluating indefinite integrals',
                    'priority': 'high',
                },
                {
                    'issue': 'Chain rule application',
                    'suggestion': 'Verify chain rule application: d/dx[f(g(x))] = f\'(g(x)) · g\'(x)',
                    'priority': 'high',
                },
                {
                    'issue': 'Improper integrals',
                    'suggestion': 'Check for improper integrals: verify convergence before evaluating',
                    'priority': 'medium',
                },
            ],
            'algebra': [
                {
                    'issue': 'Domain restrictions',
                    'suggestion': 'Identify domain restrictions: avoid division by zero and even roots of negative numbers',
                    'priority': 'high',
                },
                {
                    'issue': 'Extraneous solutions',
                    'suggestion': 'Check for extraneous solutions when squaring both sides of an equation',
                    'priority': 'high',
                },
                {
                    'issue': 'Factoring completeness',
                    'suggestion': 'Ensure complete factoring: check all factors for further simplification',
                    'priority': 'medium',
                },
            ],
            'geometry': [
                {
                    'issue': 'Unit consistency',
                    'suggestion': 'Maintain unit consistency: convert all measurements to the same unit system',
                    'priority': 'high',
                },
                {
                    'issue': 'Angle measures',
                    'suggestion': 'Clarify angle measurement: specify degrees or radians consistently',
                    'priority': 'medium',
                },
                {
                    'issue': 'Similarity conditions',
                    'suggestion': 'Verify similarity conditions: check all angle and side ratio requirements',
                    'priority': 'medium',
                },
            ],
            'statistics': [
                {
                    'issue': 'Sample vs population',
                    'suggestion': 'Distinguish between sample (n) and population (N) parameters',
                    'priority': 'high',
                },
                {
                    'issue': 'P-value interpretation',
                    'suggestion': 'Interpret p-values correctly: p < α indicates statistical significance',
                    'priority': 'high',
                },
                {
                    'issue': 'Normality assumption',
                    'suggestion': 'Verify normality assumption before applying parametric tests',
                    'priority': 'medium',
                },
            ],
            'physics': [
                {
                    'issue': 'Unit systems',
                    'suggestion': 'Choose consistent unit system: SI (m, kg, s) or CGS (cm, g, s)',
                    'priority': 'high',
                },
                {
                    'issue': 'Vector notation',
                    'suggestion': 'Use vector notation for directional quantities: distinguish magnitude and direction',
                    'priority': 'medium',
                },
                {
                    'issue': 'Sign conventions',
                    'suggestion': 'Establish clear sign conventions: define positive and negative directions',
                    'priority': 'high',
                },
            ],
            'chemistry': [
                {
                    'issue': 'Balancing equations',
                    'suggestion': 'Verify mass and charge balance in chemical equations',
                    'priority': 'high',
                },
                {
                    'issue': 'Stoichiometric ratios',
                    'suggestion': 'Use correct mole ratios from balanced equations',
                    'priority': 'high',
                },
                {
                    'issue': 'Significant figures',
                    'suggestion': 'Apply significant figure rules: reflect measurement precision',
                    'priority': 'medium',
                },
            ],
            'thermodynamics': [
                {
                    'issue': 'State variables',
                    'suggestion': 'Identify state variables correctly: distinguish path-dependent and path-independent quantities',
                    'priority': 'high',
                },
                {
                    'issue': 'Process type',
                    'suggestion': 'Specify process type: isothermal, adiabatic, isobaric, or isochoric',
                    'priority': 'high',
                },
                {
                    'issue': 'Work sign convention',
                    'suggestion': 'Apply correct work sign convention: work done BY system vs ON system',
                    'priority': 'medium',
                },
            ],
            'electromagnetism': [
                {
                    'issue': 'Circuit analysis',
                    'suggestion': 'Apply Kirchhoff\'s laws correctly: sum of voltages and currents at junctions',
                    'priority': 'high',
                },
                {
                    'issue': 'Impedance phase',
                    'suggestion': 'Consider phase angles in AC circuits: impedance has both magnitude and phase',
                    'priority': 'medium',
                },
                {
                    'issue': 'Lenz\'s law',
                    'suggestion': 'Apply Lenz\'s law: induced EMF opposes the change in magnetic flux',
                    'priority': 'high',
                },
            ],
            'quantum': [
                {
                    'issue': 'Wave function normalization',
                    'suggestion': 'Ensure wave function is normalized: ∫|ψ|² dV = 1',
                    'priority': 'high',
                },
                {
                    'issue': 'Operator hermiticity',
                    'suggestion': 'Verify operators are Hermitian: ensures real eigenvalues',
                    'priority': 'high',
                },
                {
                    'issue': 'Commutation relations',
                    'suggestion': 'Check commutation relations: [A, B] = AB - BA',
                    'priority': 'medium',
                },
            ],
            'relativity': [
                {
                    'issue': 'Reference frame',
                    'suggestion': 'Clearly specify reference frame: inertial or non-inertial observer',
                    'priority': 'high',
                },
                {
                    'issue': 'Speed of light limit',
                    'suggestion': 'Verify no information exceeds c: the universal speed limit',
                    'priority': 'high',
                },
                {
                    'issue': 'Metric signature',
                    'suggestion': 'Use consistent metric signature: (+, -, -, -) or (-, +, +, +)',
                    'priority': 'medium',
                },
            ],
            'biology': [
                {
                    'issue': 'Scale considerations',
                    'suggestion': 'Consider appropriate scale: molecular, cellular, tissue, or organism level',
                    'priority': 'medium',
                },
                {
                    'issue': 'Rate constants',
                    'suggestion': 'Use appropriate rate constants: temperature and pH dependence',
                    'priority': 'high',
                },
                {
                    'issue': 'Population assumptions',
                    'suggestion': 'State population assumptions: Hardy-Weinberg conditions',
                    'priority': 'medium',
                },
            ],
            'neuroscience': [
                {
                    'issue': 'Timescale',
                    'suggestion': 'Specify timescale: millisecond (action potentials) to years (plasticity)',
                    'priority': 'high',
                },
                {
                    'issue': 'Spatial scale',
                    'suggestion': 'Define spatial scale: nanometers (channels) to centimeters (brain regions)',
                    'priority': 'medium',
                },
                {
                    'issue': 'Simplifying assumptions',
                    'suggestion': 'State simplifying assumptions: point neurons vs detailed morphology',
                    'priority': 'medium',
                },
            ],
        }
    
    def analyze_formula(self, formula: str) -> Dict:
        """
        Analyze a formula and provide relevant scientific improvements
        
        Args:
            formula: The formula string to analyze
            
        Returns:
            Dictionary with detected domains, patterns, and suggestions
        """
        result = {
            'detected_domains': [],
            'detected_patterns': [],
            'suggestions': [],
            'warnings': [],
            'high_priority_issues': [],
        }
        
        # Detect patterns
        for category, patterns in self.patterns.items():
            for pattern in patterns:
                if re.search(pattern, formula, re.IGNORECASE):
                    result['detected_patterns'].append({
                        'category': category,
                        'pattern': pattern,
                    })
                    if category not in result['detected_domains']:
                        result['detected_domains'].append(category)
        
        # Get improvements for detected domains
        for domain in result['detected_domains']:
            if domain in self.improvements_db:
                for improvement in self.improvements_db[domain]:
                    suggestion = {
                        'domain': domain,
                        'issue': improvement['issue'],
                        'suggestion': improvement['suggestion'],
                        'priority': improvement['priority'],
                    }
                    result['suggestions'].append(suggestion)
                    
                    if improvement['priority'] == 'high':
                        result['high_priority_issues'].append(suggestion)
        
        return result
    
    def get_contextual_suggestions(
        self,
        formula: str,
        user_context: Optional[Dict] = None
    ) -> List[Dict]:
        """
        Get contextual suggestions based on formula and optional user context
        
        Args:
            formula: The formula string
            user_context: Optional dict with user expertise level, field, etc.
            
        Returns:
            List of prioritized suggestions
        """
        analysis = self.analyze_formula(formula)
        suggestions = analysis['suggestions']
        
        # Prioritize by user context if provided
        if user_context:
            expertise = user_context.get('expertise', 'intermediate')
            
            if expertise == 'beginner':
                # Prioritize fundamental issues
                suggestions = [
                    s for s in suggestions 
                    if s['priority'] == 'high'
                ]
            elif expertise == 'expert':
                # Include all suggestions
                pass
        
        # Sort by priority
        priority_order = {'high': 0, 'medium': 1, 'low': 2}
        suggestions.sort(key=lambda x: priority_order.get(x['priority'], 3))
        
        return suggestions
    
    def format_suggestions(
        self,
        suggestions: List[Dict],
        format_type: str = 'readable'
    ) -> str:
        """
        Format suggestions for display
        
        Args:
            suggestions: List of suggestion dicts
            format_type: 'readable', 'compact', or 'detailed'
            
        Returns:
            Formatted string
        """
        if format_type == 'readable':
            lines = []
            for i, s in enumerate(suggestions, 1):
                lines.append(f"\n{i}. [{s['domain'].title()}] {s['issue']}")
                lines.append(f"   {s['suggestion']}")
                lines.append(f"   Priority: {s['priority']}")
            return "\n".join(lines)
        
        elif format_type == 'compact':
            return "\n".join([
                f"• {s['issue']}: {s['suggestion']}"
                for s in suggestions
            ])
        
        elif format_type == 'detailed':
            import json
            return json.dumps(suggestions, indent=2)
        
        return ""
    
    def validate_unit_consistency(
        self,
        formula: str,
        variables: Dict[str, str]
    ) -> List[Dict]:
        """
        Validate unit consistency in a formula
        
        Args:
            formula: The formula string
            variables: Dict mapping variable names to their units
            
        Returns:
            List of unit consistency issues
        """
        issues = []
        
        # Extract variables from formula
        found_vars = set(re.findall(r'\b[a-zA-Z]\w*\b', formula))
        
        # Check if all variables have units defined
        for var in found_vars:
            if var not in variables:
                issues.append({
                    'type': 'missing_unit',
                    'variable': var,
                    'message': f'Variable "{var}" does not have a defined unit',
                })
        
        # Check for common unit mismatches
        # This is a simplified check - real implementation would need dimensional analysis
        if '+' in formula or '-' in formula:
            # Terms being added/subtracted should have same units
            pass
        
        return issues


# Example usage and testing
if __name__ == "__main__":
    engine = ScientificImprovementEngine()
    
    # Test formulas
    test_formulas = [
        "F = ma",
        "∫(x² + 1)dx",
        "E = hf",
        "PV = nRT",
        "μ = (x₁ + x₂ + ... + xₙ)/n",
        "d/dx(e^(x²))",
    ]
    
    print("=" * 60)
    print("Scientific Improvements Lookup System")
    print("=" * 60)
    
    for formula in test_formulas:
        print(f"\nAnalyzing: {formula}")
        print("-" * 60)
        
        suggestions = engine.get_contextual_suggestions(formula)
        
        if suggestions:
            formatted = engine.format_suggestions(suggestions, 'readable')
            print(formatted)
        else:
            print("No specific suggestions for this formula.")
    
    print("\n" + "=" * 60)