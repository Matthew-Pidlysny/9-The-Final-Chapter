"""
Export/Import Manager for Peer System
Handles formula export and import without modifying original code
"""
import json
import csv
from typing import Dict, Optional
from datetime import datetime


class ExportImportManager:
    """
    Manages formula export and import operations
    """
    
    def __init__(self):
        """Initialize export/import manager"""
        self.exporters = {
            'json': self._export_json,
            'text': self._export_text,
            'csv': self._export_csv,
            'markdown': self._export_markdown,
        }
        
        self.importers = {
            'json': self._import_json,
            'text': self._import_text,
            'csv': self._import_csv,
            'markdown': self._import_markdown,
        }
    
    def export(self, data: Dict, format: str = 'json') -> str:
        """
        Export formula data in specified format
        
        Args:
            data: Dictionary with formula data
            format: Export format ('json', 'text', 'csv', 'markdown')
            
        Returns:
            Exported string
        """
        exporter = self.exporters.get(format, self._export_json)
        return exporter(data)
    
    def import_formula(self, content: str, format: str = 'json') -> Optional[Dict]:
        """
        Import formula from content
        
        Args:
            content: Imported content string
            format: Import format ('json', 'text', 'csv', 'markdown')
            
        Returns:
            Dictionary with imported data
        """
        importer = self.importers.get(format, self._import_json)
        return importer(content)
    
    def _export_json(self, data: Dict) -> str:
        """Export as JSON"""
        return json.dumps(data, indent=2)
    
    def _export_text(self, data: Dict) -> str:
        """Export as plain text"""
        lines = []
        lines.append("=" * 60)
        lines.append("Formula Export")
        lines.append("=" * 60)
        lines.append(f"\nFormula: {data.get('formula', 'N/A')}")
        lines.append(f"Timestamp: {data.get('timestamp', 'N/A')}")
        
        if 'result' in data:
            result = data['result']
            lines.append(f"\nValid: {'Yes' if result.get('is_valid') else 'No'}")
            
            if result.get('errors'):
                lines.append(f"\nErrors:")
                for error in result['errors']:
                    lines.append(f"  - {error}")
            
            if result.get('warnings'):
                lines.append(f"\nWarnings:")
                for warning in result['warnings']:
                    lines.append(f"  - {warning}")
            
            if result.get('improvements'):
                lines.append(f"\nImprovements: {len(result['improvements'])}")
        
        lines.append("\n" + "=" * 60)
        
        return "\n".join(lines)
    
    def _export_csv(self, data: Dict) -> str:
        """Export as CSV"""
        import io
        output = io.StringIO()
        
        writer = csv.writer(output)
        writer.writerow(['Field', 'Value'])
        writer.writerow(['Formula', data.get('formula', '')])
        writer.writerow(['Timestamp', data.get('timestamp', '')])
        
        if 'result' in data:
            result = data['result']
            writer.writerow(['Valid', 'Yes' if result.get('is_valid') else 'No'])
            
            if result.get('errors'):
                writer.writerow(['Errors', '; '.join(result['errors'])])
            
            if result.get('warnings'):
                writer.writerow(['Warnings', '; '.join(result['warnings'])])
        
        return output.getvalue()
    
    def _export_markdown(self, data: Dict) -> str:
        """Export as Markdown"""
        lines = []
        lines.append("# Formula Export\n")
        lines.append(f"## Formula\n\n`{data.get('formula', 'N/A')}`\n")
        lines.append(f"## Timestamp\n\n{data.get('timestamp', 'N/A')}\n")
        
        if 'result' in data:
            result = data['result']
            lines.append(f"## Validation\n\n")
            lines.append(f"- **Valid**: {'Yes' if result.get('is_valid') else 'No'}\n")
            
            if result.get('errors'):
                lines.append(f"\n### Errors\n\n")
                for error in result['errors']:
                    lines.append(f"- {error}\n")
            
            if result.get('warnings'):
                lines.append(f"\n### Warnings\n\n")
                for warning in result['warnings']:
                    lines.append(f"- {warning}\n")
            
            if result.get('improvements'):
                lines.append(f"\n### Improvements\n\n")
                for i, improvement in enumerate(result['improvements'], 1):
                    lines.append(f"{i}. {improvement.get('issue', 'N/A')}\n")
        
        return "\n".join(lines)
    
    def _import_json(self, content: str) -> Optional[Dict]:
        """Import from JSON"""
        try:
            return json.loads(content)
        except json.JSONDecodeError:
            return None
    
    def _import_text(self, content: str) -> Optional[Dict]:
        """Import from plain text"""
        # Extract formula from text (simple approach)
        formula = content.strip()
        
        if formula.startswith('Formula:'):
            formula = formula.split('Formula:')[1].strip()
        
        return {
            'formula': formula,
            'timestamp': datetime.now().isoformat(),
        }
    
    def _import_csv(self, content: str) -> Optional[Dict]:
        """Import from CSV"""
        import io
        try:
            reader = csv.DictReader(io.StringIO(content))
            rows = list(reader)
            
            if rows:
                return {
                    'formula': rows[0].get('Formula', ''),
                    'timestamp': datetime.now().isoformat(),
                }
        except Exception:
            pass
        
        return None
    
    def _import_markdown(self, content: str) -> Optional[Dict]:
        """Import from Markdown"""
        # Extract formula from markdown code block
        import re
        
        # Look for code blocks
        match = re.search(r'`([^`]+)`', content)
        if match:
            formula = match.group(1)
            return {
                'formula': formula,
                'timestamp': datetime.now().isoformat(),
            }
        
        return None


if __name__ == "__main__":
    manager = ExportImportManager()
    
    # Test data
    test_data = {
        'formula': 'F = ma',
        'timestamp': datetime.now().isoformat(),
        'result': {
            'is_valid': True,
            'errors': [],
            'warnings': [],
            'improvements': [],
        }
    }
    
    print("Export/Import Manager Test")
    print("=" * 60)
    
    # Test exports
    for format in ['json', 'text', 'csv', 'markdown']:
        print(f"\n{format.upper()} Export:")
        print("-" * 60)
        exported = manager.export(test_data, format)
        print(exported)
    
    # Test imports
    print("\n\nImport Test:")
    print("-" * 60)
    json_export = manager.export(test_data, 'json')
    imported = manager.import_formula(json_export, 'json')
    print(f"Imported: {imported}")