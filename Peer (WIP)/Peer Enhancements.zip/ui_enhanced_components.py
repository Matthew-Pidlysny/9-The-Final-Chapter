"""
Enhanced UI Components for Peer System
Gentle merge approach - new UI components that complement existing Peer
"""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from typing import Optional, Dict, List, Callable
import json
from datetime import datetime


class EnhancedUIManager:
    """
    Manages enhanced UI components for Peer
    Modern, user-friendly interface without modifying original code
    """
    
    def __init__(
        self,
        validation_engine,
        improvements_engine,
        history_manager,
        template_manager,
        preview_panel,
        auto_save_manager,
        export_import_manager
    ):
        """Initialize enhanced UI manager"""
        self.validation_engine = validation_engine
        self.improvements_engine = improvements_engine
        self.history_manager = history_manager
        self.template_manager = template_manager
        self.preview_panel = preview_panel
        self.auto_save_manager = auto_save_manager
        self.export_import_manager = export_import_manager
        
        # UI state
        self.current_formula = ""
        self.validation_results = {}
        self.dark_theme = False
        self.formulas = []
        
        # Setup main window (lazy initialization)
        self.root = None
        self.setup_complete = False
    
    def run(self):
        """Run the enhanced UI"""
        if not self.setup_complete:
            self._setup_ui()
            self.setup_complete = True
        
        if self.root:
            self.root.mainloop()
    
    def _setup_ui(self):
        """Setup the enhanced UI"""
        self.root = tk.Tk()
        self.root.title("Peer Enhanced - Scientific Formula Validation")
        self.root.geometry("1400x900")
        
        # Configure styles
        self._setup_styles()
        
        # Build UI
        self._build_main_ui()
        
        # Setup keyboard shortcuts
        self._setup_shortcuts()
        
        print("✓ Enhanced UI setup complete")
    
    def _setup_styles(self):
        """Setup modern UI styles"""
        style = ttk.Style()
        style.theme_use('clam')
        
        # Color schemes
        if self.dark_theme:
            bg_color = '#1E1E1E'
            fg_color = '#FFFFFF'
            accent_color = '#4A90D9'
            success_color = '#50C878'
            warning_color = '#FFD700'
            error_color = '#F25F5C'
        else:
            bg_color = '#FFFFFF'
            fg_color = '#333333'
            accent_color = '#2E86AB'
            success_color = '#50C878'
            warning_color = '#FFD700'
            error_color = '#F25F5C'
        
        # Configure buttons
        style.configure('Primary.TButton',
                       font=('Helvetica', 11, 'bold'),
                       padding=10,
                       background=accent_color,
                       foreground='white',
                       borderwidth=0,
                       relief='flat')
        
        style.configure('Secondary.TButton',
                       font=('Helvetica', 10),
                       padding=8,
                       background='#56C1FF',
                       foreground='white',
                       borderwidth=0,
                       relief='flat')
        
        style.configure('Success.TButton',
                       font=('Helvetica', 10),
                       padding=8,
                       background=success_color,
                       foreground='white',
                       borderwidth=0,
                       relief='flat')
        
        style.configure('Danger.TButton',
                       font=('Helvetica', 10),
                       padding=8,
                       background=error_color,
                       foreground='white',
                       borderwidth=0,
                       relief='flat')
        
        # Configure labels
        style.configure('Title.TLabel',
                       font=('Helvetica', 24, 'bold'),
                       foreground=accent_color,
                       background=bg_color)
        
        style.configure('Subtitle.TLabel',
                       font=('Helvetica', 14, 'bold'),
                       foreground=fg_color,
                       background=bg_color)
        
        style.configure('Text.TLabel',
                       font=('Helvetica', 11),
                       foreground=fg_color,
                       background=bg_color)
        
        # Configure text widgets
        style.configure('Formula.Text',
                       font=('Courier New', 14),
                       background='#F8F9FA',
                       foreground='#333333',
                       padding=10)
        
        # Configure frames
        style.configure('Card.TFrame',
                       background='white',
                       relief='raised',
                       borderwidth=2)
        
        # Configure treeview
        style.configure('Treeview',
                       font=('Helvetica', 10),
                       rowheight=25)
        
        style.configure('Treeview.Heading',
                       font=('Helvetica', 11, 'bold'),
                       background=accent_color,
                       foreground='white')
        
        # Store colors for use
        self.colors = {
            'bg': bg_color,
            'fg': fg_color,
            'accent': accent_color,
            'success': success_color,
            'warning': warning_color,
            'error': error_color,
        }
    
    def _build_main_ui(self):
        """Build main UI components"""
        # Main container
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # Header
        self._build_header(main_frame)
        
        # Main content area (split view)
        content_frame = ttk.Frame(main_frame)
        content_frame.pack(fill='both', expand=True, pady=(10, 0))
        
        # Left panel - Formula input and controls
        left_panel = ttk.Frame(content_frame, width=600)
        left_panel.pack(side='left', fill='both', expand=True, padx=(0, 5))
        
        # Right panel - Results and improvements
        right_panel = ttk.Frame(content_frame, width=700)
        right_panel.pack(side='right', fill='both', expand=True, padx=(5, 0))
        
        # Build left panel components
        self._build_formula_input(left_panel)
        self._build_control_buttons(left_panel)
        
        # Build right panel components
        self._build_validation_results(right_panel)
        self._build_improvements_panel(right_panel)
        
        # Footer - Status bar
        self._build_status_bar(main_frame)
    
    def _build_header(self, parent):
        """Build header section"""
        header_frame = ttk.Frame(parent)
        header_frame.pack(fill='x', pady=(0, 10))
        
        # Title
        title_label = ttk.Label(
            header_frame,
            text="⚛ Peer Enhanced",
            style='Title.TLabel'
        )
        title_label.pack(side='left')
        
        # Subtitle
        subtitle_label = ttk.Label(
            header_frame,
            text="Scientific Formula Validation System",
            font=('Helvetica', 12),
            foreground=self.colors['fg']
        )
        subtitle_label.pack(side='left', padx=(20, 0))
        
        # Theme toggle button
        theme_button = ttk.Button(
            header_frame,
            text="🌙 Dark Theme",
            style='Secondary.TButton',
            command=self._toggle_theme
        )
        theme_button.pack(side='right')
        
        # Help button
        help_button = ttk.Button(
            header_frame,
            text="❓ Help",
            style='Secondary.TButton',
            command=self._show_help
        )
        help_button.pack(side='right', padx=5)
    
    def _build_formula_input(self, parent):
        """Build formula input section"""
        # Label
        input_label = ttk.Label(
            parent,
            text="Enter Formula:",
            style='Subtitle.TLabel'
        )
        input_label.pack(anchor='w', pady=(0, 5))
        
        # Formula input text area
        self.formula_text = tk.Text(
            parent,
            height=8,
            font=('Courier New', 14),
            bg='#F8F9FA',
            fg='#333333',
            padx=10,
            pady=10,
            wrap='word',
            insertbackground=self.colors['accent']
        )
        self.formula_text.pack(fill='both', expand=True, pady=(0, 10))
        
        # Bind events
        self.formula_text.bind('<Control-s>', lambda e: self._save_formula())
        self.formula_text.bind('<Control-z>', lambda e: self._undo())
        self.formula_text.bind('<Control-y>', lambda e: self._redo())
        self.formula_text.bind('<Key>', self._on_formula_change)
        
        # Preview label
        preview_label = ttk.Label(
            parent,
            text="Preview:",
            style='Subtitle.TLabel'
        )
        preview_label.pack(anchor='w', pady=(0, 5))
        
        # Preview area
        self.preview_label_widget = ttk.Label(
            parent,
            text="Enter a formula to see preview...",
            font=('Courier New', 12),
            background='#F0F0F0',
            foreground='#666666',
            padding=10
        )
        self.preview_label_widget.pack(fill='x')
    
    def _build_control_buttons(self, parent):
        """Build control buttons section"""
        button_frame = ttk.Frame(parent)
        button_frame.pack(fill='x', pady=10)
        
        # Validate button
        validate_button = ttk.Button(
            button_frame,
            text="✓ Validate Formula",
            style='Primary.TButton',
            command=self._validate_formula
        )
        validate_button.pack(side='left', fill='x', expand=True, padx=(0, 5))
        
        # Stuck button
        stuck_button = ttk.Button(
            button_frame,
            text="❓ Stuck? Get Help",
            style='Secondary.TButton',
            command=self._get_stuck_help
        )
        stuck_button.pack(side='left', padx=(0, 5))
        
        # Templates button
        templates_button = ttk.Button(
            button_frame,
            text="📋 Templates",
            style='Secondary.TButton',
            command=self._show_templates
        )
        templates_button.pack(side='left', padx=(0, 5))
        
        # History button
        history_button = ttk.Button(
            button_frame,
            text="📜 History",
            style='Secondary.TButton',
            command=self._show_history
        )
        history_button.pack(side='left')
        
        # Export/Import buttons
        export_button = ttk.Button(
            button_frame,
            text="📤 Export",
            style='Success.TButton',
            command=self._export_formula
        )
        export_button.pack(side='left', padx=(5, 2))
        
        import_button = ttk.Button(
            button_frame,
            text="📥 Import",
            style='Success.TButton',
            command=self._import_formula
        )
        import_button.pack(side='left', padx=(2, 5))
    
    def _build_validation_results(self, parent):
        """Build validation results section"""
        # Label
        results_label = ttk.Label(
            parent,
            text="Validation Results:",
            style='Subtitle.TLabel'
        )
        results_label.pack(anchor='w', pady=(0, 5))
        
        # Results text area
        self.results_text = tk.Text(
            parent,
            height=15,
            font=('Courier New', 11),
            bg='#F8F9FA',
            fg='#333333',
            padx=10,
            pady=10,
            wrap='word',
            state='disabled'
        )
        self.results_text.pack(fill='both', expand=True, pady=(0, 10))
        
        # Status indicator
        self.status_label = ttk.Label(
            parent,
            text="Status: Ready",
            font=('Helvetica', 10, 'bold'),
            foreground=self.colors['success']
        )
        self.status_label.pack(anchor='w')
    
    def _build_improvements_panel(self, parent):
        """Build scientific improvements panel"""
        # Label
        improvements_label = ttk.Label(
            parent,
            text="Scientific Improvements & Suggestions:",
            style='Subtitle.TLabel'
        )
        improvements_label.pack(anchor='w', pady=(0, 5))
        
        # Improvements text area
        self.improvements_text = tk.Text(
            parent,
            height=20,
            font=('Helvetica', 10),
            bg='#F8F9FA',
            fg='#333333',
            padx=10,
            py=10,
            wrap='word',
            state='disabled'
        )
        self.improvements_text.pack(fill='both', expand=True)
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(
            parent,
            orient='vertical',
            command=self.improvements_text.yview
        )
        self.improvements_text['yscrollcommand'] = scrollbar.set
    
    def _build_status_bar(self, parent):
        """Build status bar"""
        status_frame = ttk.Frame(parent)
        status_frame.pack(fill='x', pady=(10, 0))
        
        # Status text
        self.status_bar_text = ttk.Label(
            status_frame,
            text="Ready | Auto-save enabled | Last saved: Never",
            font=('Helvetica', 9),
            foreground='#666666'
        )
        self.status_bar_text.pack(side='left')
        
        # Version
        version_label = ttk.Label(
            status_frame,
            text="v2.0 Enhanced",
            font=('Helvetica', 9),
            foreground='#999999'
        )
        version_label.pack(side='right')
    
    def _setup_shortcuts(self):
        """Setup keyboard shortcuts"""
        # Ctrl+S: Save
        self.root.bind('<Control-s>', lambda e: self._save_formula())
        
        # Ctrl+V: Validate
        self.root.bind('<Control-v>', lambda e: self._validate_formula())
        
        # Ctrl+T: Templates
        self.root.bind('<Control-t>', lambda e: self._show_templates())
        
        # Ctrl+H: History
        self.root.bind('<Control-h>', lambda e: self._show_history())
        
        # F1: Help
        self.root.bind('<F1>', lambda e: self._show_help())
        
        # Ctrl+Q: Quit
        self.root.bind('<Control-q>', lambda e: self.root.quit())
    
    def _toggle_theme(self):
        """Toggle between dark and light theme"""
        self.dark_theme = not self.dark_theme
        messagebox.showinfo(
            "Theme Changed",
            f"Switched to {'dark' if self.dark_theme else 'light'} theme.\n"
            "Restart to apply full theme changes."
        )
    
    def _validate_formula(self):
        """Validate the current formula"""
        formula = self.formula_text.get("1.0", "end-1c").strip()
        
        if not formula:
            messagebox.showwarning(
                "Empty Formula",
                "Please enter a formula to validate."
            )
            return
        
        # Update status
        self.status_label.config(
            text="Status: Validating...",
            foreground=self.colors['warning']
        )
        self.root.update()
        
        try:
            # Validate using enhanced engine
            result = self.validation_engine.validate(formula)
            
            # Display results
            self._display_validation_results(result)
            
            # Display improvements
            self._display_improvements(result)
            
            # Update status
            if result.get('is_valid', False):
                self.status_label.config(
                    text="Status: ✓ Valid",
                    foreground=self.colors['success']
                )
            else:
                self.status_label.config(
                    text="Status: ✗ Invalid",
                    foreground=self.colors['error']
                )
            
            # Save to history
            self.history_manager.save_formula(formula, result)
            
        except Exception as e:
            self._show_error(f"Validation error: {str(e)}")
            self.status_label.config(
                text="Status: Error",
                foreground=self.colors['error']
            )
    
    def _display_validation_results(self, result: dict):
        """Display validation results"""
        self.results_text.config(state='normal')
        self.results_text.delete("1.0", "end")
        
        # Build results text
        lines = []
        lines.append("=" * 60)
        lines.append("VALIDATION RESULTS")
        lines.append("=" * 60)
        lines.append(f"\nFormula: {result.get('formula', 'N/A')}")
        lines.append(f"\nValid: {'✓ Yes' if result.get('is_valid', False) else '✗ No'}")
        
        # Errors
        if result.get('errors'):
            lines.append(f"\nErrors ({len(result['errors'])}):")
            for i, error in enumerate(result['errors'], 1):
                lines.append(f"  {i}. {error}")
        
        # Warnings
        if result.get('warnings'):
            lines.append(f"\nWarnings ({len(result['warnings'])}):")
            for i, warning in enumerate(result['warnings'], 1):
                lines.append(f"  {i}. {warning}")
        
        # Scientific domain
        if result.get('scientific_domain'):
            lines.append(f"\nDetected Domains: {', '.join(result['scientific_domain'])}")
        
        # Timestamp
        if result.get('timestamp'):
            lines.append(f"\nValidated: {result['timestamp']}")
        
        lines.append("\n" + "=" * 60)
        
        # Insert text
        self.results_text.insert("1.0", "\n".join(lines))
        self.results_text.config(state='disabled')
    
    def _display_improvements(self, result: dict):
        """Display scientific improvements"""
        self.improvements_text.config(state='normal')
        self.improvements_text.delete("1.0", "end")
        
        improvements = result.get('improvements', [])
        
        if not improvements:
            self.improvements_text.insert("1.0", "No specific improvements for this formula.")
        else:
            lines = []
            lines.append("=" * 60)
            lines.append("SCIENTIFIC IMPROVEMENTS & SUGGESTIONS")
            lines.append("=" * 60)
            
            for i, improvement in enumerate(improvements, 1):
                lines.append(f"\n{i}. [{improvement.get('domain', 'General').title()}]")
                lines.append(f"   Issue: {improvement.get('issue', 'N/A')}")
                lines.append(f"   Suggestion: {improvement.get('suggestion', 'N/A')}")
                lines.append(f"   Priority: {improvement.get('priority', 'medium').upper()}")
            
            lines.append("\n" + "=" * 60)
            
            self.improvements_text.insert("1.0", "\n".join(lines))
        
        self.improvements_text.config(state='disabled')
    
    def _get_stuck_help(self):
        """Get help for stuck user"""
        formula = self.formula_text.get("1.0", "end-1c").strip()
        
        if not formula:
            messagebox.showwarning(
                "Empty Formula",
                "Please enter a formula to get help with."
            )
            return
        
        try:
            from stuck_button_assistant import StuckButtonAssistant
            
            assistant = StuckButtonAssistant()
            help_result = assistant.analyze_and_help(formula)
            
            # Display help in new window
            self._show_stuck_help_window(help_result)
            
        except Exception as e:
            messagebox.showerror(
                "Error",
                f"Could not get help: {str(e)}"
            )
    
    def _show_stuck_help_window(self, help_result: dict):
        """Show stuck help in a new window"""
        window = tk.Toplevel(self.root)
        window.title("Stuck? Get Help")
        window.geometry("600x500")
        
        # Text area
        text = tk.Text(
            window,
            font=('Helvetica', 11),
            padx=15,
            pady=15,
            wrap='word'
        )
        text.pack(fill='both', expand=True)
        
        # Build help text
        lines = []
        lines.append("Help for your formula:\n")
        lines.append("=" * 60)
        
        # Analysis
        if help_result.get('analysis'):
            lines.append(f"\nAnalysis:\n{help_result['analysis']}")
        
        # Suggestions
        if help_result.get('suggestions'):
            lines.append(f"\nSuggestions:\n")
            for i, suggestion in enumerate(help_result['suggestions'], 1):
                lines.append(f"{i}. {suggestion}")
        
        # Examples
        if help_result.get('examples'):
            lines.append(f"\nExamples:\n")
            for i, example in enumerate(help_result['examples'], 1):
                lines.append(f"{i}. {example}")
        
        text.insert("1.0", "\n".join(lines))
        text.config(state='disabled')
        
        # Close button
        close_button = ttk.Button(
            window,
            text="Close",
            style='Primary.TButton',
            command=window.destroy
        )
        close_button.pack(pady=10)
    
    def _show_templates(self):
        """Show templates dialog"""
        templates = self.template_manager.list_templates()
        
        window = tk.Toplevel(self.root)
        window.title("Formula Templates")
        window.geometry("500x400")
        
        # Label
        label = ttk.Label(
            window,
            text="Select a template:",
            style='Subtitle.TLabel'
        )
        label.pack(pady=10)
        
        # Template list
        listbox = tk.Listbox(
            window,
            font=('Helvetica', 11),
            height=15
        )
        listbox.pack(fill='both', expand=True, padx=10, pady=5)
        
        for template in templates:
            listbox.insert('end', template['name'])
        
        # Use template button
        def use_template():
            selection = listbox.curselection()
            if selection:
                template_name = templates[selection[0]]['name']
                template = self.template_manager.get_template(template_name)
                self.formula_text.delete("1.0", "end")
                self.formula_text.insert("1.0", template['formula'])
                self._update_preview()
                window.destroy()
        
        button = ttk.Button(
            window,
            text="Use Template",
            style='Primary.TButton',
            command=use_template
        )
        button.pack(pady=10)
    
    def _show_history(self):
        """Show formula history"""
        history = self.history_manager.get_history(50)
        
        window = tk.Toplevel(self.root)
        window.title("Formula History")
        window.geometry("700x500")
        
        # Label
        label = ttk.Label(
            window,
            text="Recent Formulas:",
            style='Subtitle.TLabel'
        )
        label.pack(pady=10)
        
        # Treeview for history
        tree = ttk.Treeview(
            window,
            columns=('timestamp', 'formula', 'valid'),
            show='headings',
            height=15
        )
        tree.heading('timestamp', text='Time')
        tree.heading('formula', text='Formula')
        tree.heading('valid', text='Valid')
        tree.column('timestamp', width=150)
        tree.column('formula', width=400)
        tree.column('valid', width=70)
        tree.pack(fill='both', expand=True, padx=10, pady=5)
        
        # Add history items
        for item in history:
            tree.insert('', 'end', values=(
                item.get('timestamp', ''),
                item.get('formula', '')[:50] + '...' if len(item.get('formula', '')) > 50 else item.get('formula', ''),
                '✓' if item.get('result', {}).get('is_valid') else '✗'
            ))
        
        # Load button
        def load_formula():
            selection = tree.selection()
            if selection:
                item = tree.item(selection[0])
                formula = item['values'][1]
                self.formula_text.delete("1.0", "end")
                self.formula_text.insert("1.0", formula)
                self._update_preview()
                window.destroy()
        
        button = ttk.Button(
            window,
            text="Load Formula",
            style='Primary.TButton',
            command=load_formula
        )
        button.pack(pady=10)
    
    def _export_formula(self):
        """Export current formula"""
        formula = self.formula_text.get("1.0", "end-1c").strip()
        
        if not formula:
            messagebox.showwarning(
                "Empty Formula",
                "Please enter a formula to export."
            )
            return
        
        # Get format from user
        formats = ['JSON', 'Text', 'CSV', 'Markdown']
        format_window = tk.Toplevel(self.root)
        format_window.title("Select Export Format")
        format_window.geometry("300x200")
        
        ttk.Label(
            format_window,
            text="Select format:",
            style='Subtitle.TLabel'
        ).pack(pady=10)
        
        selected_format = tk.StringVar(value='JSON')
        
        for fmt in formats:
            ttk.Radiobutton(
                format_window,
                text=fmt,
                variable=selected_format,
                value=fmt.lower()
            ).pack(pady=5)
        
        def do_export():
            fmt = selected_format.get()
            try:
                result = {
                    'formula': formula,
                    'timestamp': datetime.now().isoformat()
                }
                exported = self.export_import_manager.export(result, fmt)
                
                # Save to file
                filename = filedialog.asksaveasfilename(
                    defaultextension=f'.{fmt.lower()}',
                    filetypes=[(f'{fmt} files', f'*.{fmt.lower()}')]
                )
                
                if filename:
                    with open(filename, 'w') as f:
                        f.write(exported)
                    
                    messagebox.showinfo(
                        "Export Successful",
                        f"Formula exported to {filename}"
                    )
                
                format_window.destroy()
                
            except Exception as e:
                messagebox.showerror(
                    "Export Error",
                    f"Could not export formula: {str(e)}"
                )
        
        ttk.Button(
            format_window,
            text="Export",
            style='Primary.TButton',
            command=do_export
        ).pack(pady=10)
    
    def _import_formula(self):
        """Import a formula"""
        filename = filedialog.askopenfilename(
            filetypes=[
                ('All files', '*.*'),
                ('JSON files', '*.json'),
                ('Text files', '*.txt'),
                ('CSV files', '*.csv'),
                ('Markdown files', '*.md')
            ]
        )
        
        if filename:
            try:
                with open(filename, 'r') as f:
                    content = f.read()
                
                # Determine format from extension
                ext = filename.split('.')[-1].lower()
                imported = self.export_import_manager.import_formula(content, ext)
                
                if imported:
                    formula = imported.get('formula', content)
                    self.formula_text.delete("1.0", "end")
                    self.formula_text.insert("1.0", formula)
                    self._update_preview()
                    
                    messagebox.showinfo(
                        "Import Successful",
                        "Formula imported successfully!"
                    )
                
            except Exception as e:
                messagebox.showerror(
                    "Import Error",
                    f"Could not import formula: {str(e)}"
                )
    
    def _save_formula(self):
        """Save formula"""
        formula = self.formula_text.get("1.0", "end-1c").strip()
        
        if not formula:
            return
        
        try:
            # Save to history
            result = self.validation_engine.validate(formula)
            self.history_manager.save_formula(formula, result)
            
            # Update status bar
            self.status_bar_text.config(
                text=f"Ready | Auto-save enabled | Last saved: {datetime.now().strftime('%H:%M:%S')}"
            )
            
        except Exception as e:
            self._show_error(f"Save error: {str(e)}")
    
    def _undo(self):
        """Undo last action"""
        messagebox.showinfo(
            "Undo",
            "Undo functionality would restore previous formula state."
        )
    
    def _redo(self):
        """Redo last undone action"""
        messagebox.showinfo(
            "Redo",
            "Redo functionality would reapply undone action."
        )
    
    def _on_formula_change(self, event):
        """Handle formula text change"""
        self._update_preview()
        return 'break'
    
    def _update_preview(self):
        """Update formula preview"""
        formula = self.formula_text.get("1.0", "end-1c").strip()
        
        if not formula:
            self.preview_label_widget.config(
                text="Enter a formula to see preview..."
            )
            return
        
        try:
            # Get preview
            preview = self.preview_panel.render(formula, 'latex')
            self.preview_label_widget.config(text=preview)
        except:
            self.preview_label_widget.config(text=formula)
    
    def _show_help(self):
        """Show help dialog"""
        help_text = """
        Peer Enhanced - Help
        
        Keyboard Shortcuts:
        • Ctrl+S: Save formula
        • Ctrl+V: Validate formula
        • Ctrl+T: Show templates
        • Ctrl+H: Show history
        • Ctrl+Z: Undo
        • Ctrl+Y: Redo
        • F1: Help
        • Ctrl+Q: Quit
        
        Features:
        • Formula validation with error detection
        • Scientific improvement suggestions
        • Formula templates
        • History tracking
        • Auto-save
        • Export/Import formulas
        • Stuck button for help
        
        For more help, try the interactive tutorials!
        """
        
        messagebox.showinfo(
            "Help",
            help_text
        )
    
    def _show_error(self, message: str):
        """Show error message"""
        messagebox.showerror(
            "Error",
            message
        )