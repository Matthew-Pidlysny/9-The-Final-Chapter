"""
Template Manager for Peer System
Provides formula templates without modifying original code
"""
import json
from typing import Dict, List, Optional


class TemplateManager:
    """
    Manages formula templates for quick insertion
    """
    
    def __init__(self):
        """Initialize template manager"""
        self.templates = self._load_templates()
    
    def _load_templates(self) -> Dict:
        """Load built-in templates"""
        return {
            # Physics templates
            'newton_second_law': {
                'name': "Newton's Second Law",
                'category': 'Physics',
                'formula': 'F = ma',
                'description': 'Force equals mass times acceleration',
                'variables': {
                    'F': 'Force (Newtons)',
                    'm': 'Mass (kg)',
                    'a': 'Acceleration (m/s²)',
                }
            },
            'kinetic_energy': {
                'name': 'Kinetic Energy',
                'category': 'Physics',
                'formula': 'KE = (1/2)mv²',
                'description': 'Kinetic energy of an object',
                'variables': {
                    'KE': 'Kinetic Energy (Joules)',
                    'm': 'Mass (kg)',
                    'v': 'Velocity (m/s)',
                }
            },
            'einstein_mass_energy': {
                'name': "Einstein's Mass-Energy",
                'category': 'Physics',
                'formula': 'E = mc²',
                'description': 'Mass-energy equivalence',
                'variables': {
                    'E': 'Energy (Joules)',
                    'm': 'Mass (kg)',
                    'c': 'Speed of light (3×10⁸ m/s)',
                }
            },
            'ohms_law': {
                'name': "Ohm's Law",
                'category': 'Physics',
                'formula': 'V = IR',
                'description': 'Voltage equals current times resistance',
                'variables': {
                    'V': 'Voltage (Volts)',
                    'I': 'Current (Amperes)',
                    'R': 'Resistance (Ohms)',
                }
            },
            'ideal_gas_law': {
                'name': 'Ideal Gas Law',
                'category': 'Chemistry',
                'formula': 'PV = nRT',
                'description': 'Pressure-volume-temperature relationship',
                'variables': {
                    'P': 'Pressure (Pa)',
                    'V': 'Volume (m³)',
                    'n': 'Moles (mol)',
                    'R': 'Gas constant (8.314 J/(mol·K))',
                    'T': 'Temperature (K)',
                }
            },
            # Mathematics templates
            'quadratic_formula': {
                'name': 'Quadratic Formula',
                'category': 'Mathematics',
                'formula': 'x = (-b ± √(b² - 4ac)) / (2a)',
                'description': 'Solution to ax² + bx + c = 0',
                'variables': {
                    'a': 'Quadratic coefficient',
                    'b': 'Linear coefficient',
                    'c': 'Constant term',
                }
            },
            'pythagorean_theorem': {
                'name': 'Pythagorean Theorem',
                'category': 'Mathematics',
                'formula': 'a² + b² = c²',
                'description': 'Relationship in right triangles',
                'variables': {
                    'a': 'Leg 1',
                    'b': 'Leg 2',
                    'c': 'Hypotenuse',
                }
            },
            'circle_area': {
                'name': 'Circle Area',
                'category': 'Mathematics',
                'formula': 'A = πr²',
                'description': 'Area of a circle',
                'variables': {
                    'A': 'Area',
                    'r': 'Radius',
                }
            },
            # Calculus templates
            'power_rule_derivative': {
                'name': 'Power Rule Derivative',
                'category': 'Calculus',
                'formula': 'd/dx(xⁿ) = nxⁿ⁻¹',
                'description': 'Derivative of power function',
                'variables': {
                    'n': 'Exponent',
                    'x': 'Variable',
                }
            },
            'basic_integral': {
                'name': 'Basic Power Integral',
                'category': 'Calculus',
                'formula': '∫xⁿ dx = (xⁿ⁺¹)/(n+1) + C',
                'description': 'Integral of power function',
                'variables': {
                    'n': 'Exponent (n ≠ -1)',
                    'x': 'Variable',
                    'C': 'Constant of integration',
                }
            },
            # Statistics templates
            'mean': {
                'name': 'Arithmetic Mean',
                'category': 'Statistics',
                'formula': 'μ = (x₁ + x₂ + ... + xₙ) / n',
                'description': 'Average of values',
                'variables': {
                    'μ': 'Mean',
                    'n': 'Number of values',
                }
            },
            'standard_deviation': {
                'name': 'Standard Deviation',
                'category': 'Statistics',
                'formula': 'σ = √[Σ(xᵢ - μ)² / n]',
                'description': 'Measure of spread',
                'variables': {
                    'σ': 'Standard deviation',
                    'μ': 'Mean',
                    'n': 'Number of values',
                }
            },
            # Chemistry templates
            'molar_mass': {
                'name': 'Molar Mass Calculation',
                'category': 'Chemistry',
                'formula': 'm = M × n',
                'description': 'Mass from moles',
                'variables': {
                    'm': 'Mass (g)',
                    'M': 'Molar mass (g/mol)',
                    'n': 'Moles (mol)',
                }
            },
            'ph_calculation': {
                'name': 'pH Calculation',
                'category': 'Chemistry',
                'formula': 'pH = -log[H⁺]',
                'description': 'pH from hydrogen ion concentration',
                'variables': {
                    'pH': 'pH value',
                    '[H⁺]': 'Hydrogen ion concentration (mol/L)',
                }
            },
        }
    
    def get_template(self, name: str) -> Optional[Dict]:
        """Get a template by name"""
        return self.templates.get(name)
    
    def list_templates(self, category: str = None) -> List[Dict]:
        """List all templates, optionally filtered by category"""
        templates = []
        
        for key, template in self.templates.items():
            if category is None or template.get('category') == category:
                templates.append({
                    'key': key,
                    'name': template.get('name'),
                    'category': template.get('category'),
                    'formula': template.get('formula'),
                })
        
        templates.sort(key=lambda t: (t.get('category', ''), t.get('name', '')))
        return templates
    
    def get_categories(self) -> List[str]:
        """Get list of unique categories"""
        categories = set()
        for template in self.templates.values():
            categories.add(template.get('category', 'General'))
        return sorted(list(categories))


if __name__ == "__main__":
    manager = TemplateManager()
    print(f"Loaded {len(manager.templates)} templates")
    print(f"Categories: {manager.get_categories()}")