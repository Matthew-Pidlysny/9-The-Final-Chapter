"""
Auto-Save Manager for Peer System
Automatically saves formulas without modifying original code
"""
import json
import os
import threading
import time
from typing import Dict, Optional
from datetime import datetime


class AutoSaveManager:
    """
    Manages automatic saving of formulas
    """
    
    def __init__(self, auto_save_file: str = "auto_save.json", interval: int = 30):
        """
        Initialize auto-save manager
        
        Args:
            auto_save_file: Path to auto-save file
            interval: Auto-save interval in seconds
        """
        self.auto_save_file = auto_save_file
        self.interval = interval
        self.current_formula = ""
        self.current_result = None
        self.last_saved = None
        self.auto_save_enabled = True
        self.timer = None
        self.lock = threading.Lock()
        
        # Load existing auto-save
        self._load_auto_save()
        
        # Start auto-save timer
        self._start_timer()
    
    def _load_auto_save(self):
        """Load auto-save data from file"""
        if os.path.exists(self.auto_save_file):
            try:
                with open(self.auto_save_file, 'r') as f:
                    data = json.load(f)
                    self.current_formula = data.get('formula', '')
                    self.current_result = data.get('result')
                    self.last_saved = data.get('timestamp')
                    print(f"Auto-save loaded from {self.last_saved}")
            except Exception as e:
                print(f"Warning: Could not load auto-save: {e}")
    
    def _save_auto_save(self):
        """Save current state to auto-save file"""
        try:
            data = {
                'formula': self.current_formula,
                'result': self.current_result,
                'timestamp': datetime.now().isoformat(),
            }
            
            with open(self.auto_save_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            self.last_saved = datetime.now().isoformat()
            print(f"Auto-saved at {self.last_saved}")
            
        except Exception as e:
            print(f"Warning: Could not auto-save: {e}")
    
    def _start_timer(self):
        """Start auto-save timer"""
        if self.timer:
            return
        
        def timer_func():
            while self.auto_save_enabled:
                time.sleep(self.interval)
                if self.auto_save_enabled and self.current_formula:
                    with self.lock:
                        self._save_auto_save()
        
        self.timer = threading.Thread(target=timer_func, daemon=True)
        self.timer.start()
    
    def save(self, formula: str, result: Optional[Dict] = None) -> bool:
        """
        Save formula state for auto-save
        
        Args:
            formula: The formula string
            result: Optional validation result
            
        Returns:
            True if saved successfully
        """
        with self.lock:
            self.current_formula = formula
            self.current_result = result
            return True
    
    def get_restored_state(self) -> Optional[Dict]:
        """
        Get restored state from auto-save
        
        Returns:
            Dictionary with formula and result
        """
        if not self.current_formula:
            return None
        
        return {
            'formula': self.current_formula,
            'result': self.current_result,
            'timestamp': self.last_saved,
        }
    
    def clear_auto_save(self) -> bool:
        """Clear auto-save data"""
        with self.lock:
            self.current_formula = ""
            self.current_result = None
            self.last_saved = None
            
            if os.path.exists(self.auto_save_file):
                try:
                    os.remove(self.auto_save_file)
                except Exception as e:
                    print(f"Warning: Could not remove auto-save file: {e}")
            
            return True


if __name__ == "__main__":
    manager = AutoSaveManager(interval=5)
    print("Auto-Save Manager Test")
    test_formulas = ["F = ma", "E = mc^2", "∫ x^2 dx"]
    for i, formula in enumerate(test_formulas):
        print(f"\nSaving formula {i+1}: {formula}")
        manager.save(formula, {'is_valid': True})
        time.sleep(2)
    print("\nAuto-save test complete!")