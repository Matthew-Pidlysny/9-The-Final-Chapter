"""
Test Suite for Peer Enhanced System
Tests all enhancements with 5 formulas and verifies functionality
"""
import sys
import os

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


class EnhancedSystemTester:
    """
    Comprehensive tester for Peer Enhanced System
    """
    
    def __init__(self):
        """Initialize tester"""
        self.test_results = []
        self.formulas_to_test = [
            {
                'name': 'Newton\'s Second Law',
                'formula': 'F = ma',
                'expected_valid': True,
                'expected_domain': ['physics', 'mathematical'],
            },
            {
                'name': 'Einstein\'s Mass-Energy',
                'formula': 'E = mc²',
                'expected_valid': True,
                'expected_domain': ['physics'],
            },
            {
                'name': 'Basic Integral',
                'formula': '∫ x² dx',
                'expected_valid': True,
                'expected_domain': ['calculus', 'mathematical'],
            },
            {
                'name': 'Ideal Gas Law',
                'formula': 'PV = nRT',
                'expected_valid': True,
                'expected_domain': ['chemistry', 'physics'],
            },
            {
                'name': 'Arithmetic Mean',
                'formula': 'μ = (x₁ + x₂ + x₃) / 3',
                'expected_valid': True,
                'expected_domain': ['statistics', 'mathematical'],
            },
        ]
    
    def test_all(self):
        """Run all tests"""
        print("=" * 80)
        print("PEER ENHANCED SYSTEM - COMPREHENSIVE TEST SUITE")
        print("=" * 80)
        print()
        
        # Test individual components
        self.test_scientific_improvements_lookup()
        self.test_validation_engine()
        self.test_template_manager()
        self.test_history_manager()
        self.test_preview_panel()
        self.test_export_import()
        self.test_auto_save()
        
        # Test integrated system
        self.test_integrated_system()
        
        # Summary
        self.print_summary()
    
    def test_scientific_improvements_lookup(self):
        """Test scientific improvements lookup system"""
        print("\n" + "=" * 80)
        print("TEST 1: Scientific Improvements Lookup System")
        print("=" * 80)
        
        try:
            from scientific_improvements_lookup import ScientificImprovementEngine
            
            engine = ScientificImprovementEngine()
            
            passed = 0
            failed = 0
            
            for test_case in self.formulas_to_test:
                formula = test_case['formula']
                
                try:
                    result = engine.analyze_formula(formula)
                    
                    # Check if improvements are provided
                    has_improvements = len(result.get('suggestions', [])) > 0
                    
                    # Check if domains are detected
                    has_domains = len(result.get('detected_domains', [])) > 0
                    
                    if has_improvements and has_domains:
                        print(f"  ✓ {test_case['name']}: {len(result['suggestions'])} improvements, {len(result['detected_domains'])} domains")
                        passed += 1
                    else:
                        print(f"  ✗ {test_case['name']}: No improvements or domains detected")
                        failed += 1
                        
                except Exception as e:
                    print(f"  ✗ {test_case['name']}: Error - {str(e)}")
                    failed += 1
            
            self.test_results.append({
                'test': 'Scientific Improvements Lookup',
                'passed': passed,
                'failed': failed,
                'total': passed + failed,
            })
            
            print(f"\nResult: {passed}/{passed+failed} passed")
            
        except Exception as e:
            print(f"  ✗ Failed to initialize: {str(e)}")
            self.test_results.append({
                'test': 'Scientific Improvements Lookup',
                'passed': 0,
                'failed': len(self.formulas_to_test),
                'total': len(self.formulas_to_test),
            })
    
    def test_validation_engine(self):
        """Test enhanced validation engine"""
        print("\n" + "=" * 80)
        print("TEST 2: Enhanced Validation Engine")
        print("=" * 80)
        
        try:
            from validation_enhanced import EnhancedValidationEngine
            
            engine = EnhancedValidationEngine()
            
            passed = 0
            failed = 0
            
            for test_case in self.formulas_to_test:
                formula = test_case['formula']
                
                try:
                    result = engine.validate(formula)
                    
                    # Check if validation completed
                    has_result = 'is_valid' in result
                    
                    # Check if errors/warnings provided
                    has_feedback = bool(result.get('errors') or result.get('warnings') or result.get('suggestions'))
                    
                    if has_result and has_feedback:
                        print(f"  ✓ {test_case['name']}: Valid={result['is_valid']}, {len(result.get('errors', []))} errors, {len(result.get('warnings', []))} warnings")
                        passed += 1
                    else:
                        print(f"  ✗ {test_case['name']}: Incomplete validation result")
                        failed += 1
                        
                except Exception as e:
                    print(f"  ✗ {test_case['name']}: Error - {str(e)}")
                    failed += 1
            
            self.test_results.append({
                'test': 'Enhanced Validation Engine',
                'passed': passed,
                'failed': failed,
                'total': passed + failed,
            })
            
            print(f"\nResult: {passed}/{passed+failed} passed")
            
        except Exception as e:
            print(f"  ✗ Failed to initialize: {str(e)}")
            self.test_results.append({
                'test': 'Enhanced Validation Engine',
                'passed': 0,
                'failed': len(self.formulas_to_test),
                'total': len(self.formulas_to_test),
            })
    
    def test_template_manager(self):
        """Test template manager"""
        print("\n" + "=" * 80)
        print("TEST 3: Template Manager")
        print("=" * 80)
        
        try:
            from template_manager import TemplateManager
            
            manager = TemplateManager()
            
            # Test listing templates
            templates = manager.list_templates()
            print(f"  ✓ Loaded {len(templates)} templates")
            
            # Test getting categories
            categories = manager.get_categories()
            print(f"  ✓ Found {len(categories)} categories: {', '.join(categories)}")
            
            # Test getting specific template
            template = manager.get_template('newton_second_law')
            if template and 'formula' in template:
                print(f"  ✓ Retrieved template: {template['name']}")
                passed = 3
            else:
                print(f"  ✗ Failed to retrieve template")
                passed = 2
            
            self.test_results.append({
                'test': 'Template Manager',
                'passed': passed,
                'failed': 0,
                'total': passed,
            })
            
            print(f"\nResult: {passed}/{passed} passed")
            
        except Exception as e:
            print(f"  ✗ Failed: {str(e)}")
            self.test_results.append({
                'test': 'Template Manager',
                'passed': 0,
                'failed': 3,
                'total': 3,
            })
    
    def test_history_manager(self):
        """Test history manager"""
        print("\n" + "=" * 80)
        print("TEST 4: History Manager")
        print("=" * 80)
        
        try:
            from formula_history_manager import FormulaHistoryManager
            
            manager = FormulaHistoryManager(history_file="test_history.json")
            
            passed = 0
            failed = 0
            
            # Test saving formulas
            for test_case in self.formulas_to_test:
                try:
                    manager.save_formula(test_case['formula'], {'is_valid': True})
                    print(f"  ✓ Saved: {test_case['name']}")
                    passed += 1
                except Exception as e:
                    print(f"  ✗ Save failed: {test_case['name']} - {str(e)}")
                    failed += 1
            
            # Test retrieving history
            history = manager.get_history(5)
            if len(history) == len(self.formulas_to_test):
                print(f"  ✓ Retrieved {len(history)} history entries")
                passed += 1
            else:
                print(f"  ✗ History count mismatch: expected {len(self.formulas_to_test)}, got {len(history)}")
                failed += 1
            
            # Test statistics
            stats = manager.get_stats()
            if stats['total'] > 0:
                print(f"  ✓ Statistics: {stats['total']} total, {stats['valid']} valid ({stats['success_rate']:.1f}%)")
                passed += 1
            else:
                print(f"  ✗ No statistics available")
                failed += 1
            
            # Clean up
            manager.clear_history()
            
            self.test_results.append({
                'test': 'History Manager',
                'passed': passed,
                'failed': failed,
                'total': passed + failed,
            })
            
            print(f"\nResult: {passed}/{passed+failed} passed")
            
        except Exception as e:
            print(f"  ✗ Failed: {str(e)}")
            self.test_results.append({
                'test': 'History Manager',
                'passed': 0,
                'failed': 7,
                'total': 7,
            })
    
    def test_preview_panel(self):
        """Test formula preview panel"""
        print("\n" + "=" * 80)
        print("TEST 5: Formula Preview Panel")
        print("=" * 80)
        
        try:
            from formula_preview_panel import FormulaPreviewPanel
            
            panel = FormulaPreviewPanel()
            
            passed = 0
            failed = 0
            
            for test_case in self.formulas_to_test:
                formula = test_case['formula']
                
                try:
                    # Test LaTeX rendering
                    latex = panel.render(formula, 'latex')
                    if latex and '$' in latex:
                        print(f"  ✓ {test_case['name']}: LaTeX render")
                        passed += 1
                    else:
                        print(f"  ✗ {test_case['name']}: LaTeX render failed")
                        failed += 1
                    
                except Exception as e:
                    print(f"  ✗ {test_case['name']}: Error - {str(e)}")
                    failed += 1
            
            self.test_results.append({
                'test': 'Formula Preview Panel',
                'passed': passed,
                'failed': failed,
                'total': passed + failed,
            })
            
            print(f"\nResult: {passed}/{passed+failed} passed")
            
        except Exception as e:
            print(f"  ✗ Failed: {str(e)}")
            self.test_results.append({
                'test': 'Formula Preview Panel',
                'passed': 0,
                'failed': len(self.formulas_to_test),
                'total': len(self.formulas_to_test),
            })
    
    def test_export_import(self):
        """Test export/import manager"""
        print("\n" + "=" * 80)
        print("TEST 6: Export/Import Manager")
        print("=" * 80)
        
        try:
            from export_import_manager import ExportImportManager
            from datetime import datetime
            
            manager = ExportImportManager()
            
            test_data = {
                'formula': 'F = ma',
                'timestamp': datetime.now().isoformat(),
                'result': {'is_valid': True},
            }
            
            passed = 0
            failed = 0
            
            # Test each export format
            for format in ['json', 'text', 'csv', 'markdown']:
                try:
                    exported = manager.export(test_data, format)
                    imported = manager.import_formula(exported, format)
                    
                    if imported and 'formula' in imported:
                        print(f"  ✓ {format.upper()} export/import: {imported['formula']}")
                        passed += 1
                    else:
                        print(f"  ✗ {format.upper()} import failed")
                        failed += 1
                        
                except Exception as e:
                    print(f"  ✗ {format.upper()}: Error - {str(e)}")
                    failed += 1
            
            self.test_results.append({
                'test': 'Export/Import Manager',
                'passed': passed,
                'failed': failed,
                'total': passed + failed,
            })
            
            print(f"\nResult: {passed}/{passed+failed} passed")
            
        except Exception as e:
            print(f"  ✗ Failed: {str(e)}")
            self.test_results.append({
                'test': 'Export/Import Manager',
                'passed': 0,
                'failed': 4,
                'total': 4,
            })
    
    def test_auto_save(self):
        """Test auto-save manager"""
        print("\n" + "=" * 80)
        print("TEST 7: Auto-Save Manager")
        print("=" * 80)
        
        try:
            from auto_save_manager import AutoSaveManager
            
            manager = AutoSaveManager(auto_save_file="test_auto_save.json", interval=1)
            
            passed = 0
            failed = 0
            
            # Test saving
            for test_case in self.formulas_to_test[:2]:  # Test with 2 formulas
                try:
                    manager.save(test_case['formula'], {'is_valid': True})
                    print(f"  ✓ Auto-save: {test_case['name']}")
                    passed += 1
                except Exception as e:
                    print(f"  ✗ Save failed: {test_case['name']} - {str(e)}")
                    failed += 1
            
            # Test restore
            import time
            time.sleep(2)  # Wait for auto-save
            restored = manager.get_restored_state()
            if restored and 'formula' in restored:
                print(f"  ✓ Restore: {restored['formula']}")
                passed += 1
            else:
                print(f"  ✗ Restore failed")
                failed += 1
            
            # Clean up
            manager.clear_auto_save()
            print(f"  ✓ Auto-save cleared")
            passed += 1
            
            self.test_results.append({
                'test': 'Auto-Save Manager',
                'passed': passed,
                'failed': failed,
                'total': passed + failed,
            })
            
            print(f"\nResult: {passed}/{passed+failed} passed")
            
        except Exception as e:
            print(f"  ✗ Failed: {str(e)}")
            self.test_results.append({
                'test': 'Auto-Save Manager',
                'passed': 0,
                'failed': 4,
                'total': 4,
            })
    
    def test_integrated_system(self):
        """Test fully integrated system"""
        print("\n" + "=" * 80)
        print("TEST 8: Integrated Peer Enhanced System")
        print("=" * 80)
        
        try:
            from peer_enhanced_main import PeerEnhanced
            
            system = PeerEnhanced()
            
            passed = 0
            failed = 0
            
            for test_case in self.formulas_to_test:
                formula = test_case['formula']
                
                try:
                    # Validate formula through integrated system
                    result = system.validate_formula(formula)
                    
                    # Check all components worked
                    has_validation = 'is_valid' in result
                    has_improvements = 'improvements' in result
                    has_domain = 'scientific_domain' in result
                    has_timestamp = 'timestamp' in result
                    
                    if has_validation and has_improvements and has_domain and has_timestamp:
                        print(f"  ✓ {test_case['name']}: Valid={result['is_valid']}, {len(result['improvements'])} improvements, {result['scientific_domain']}")
                        passed += 1
                    else:
                        print(f"  ✗ {test_case['name']}: Incomplete result")
                        failed += 1
                        
                except Exception as e:
                    print(f"  ✗ {test_case['name']}: Error - {str(e)}")
                    failed += 1
            
            self.test_results.append({
                'test': 'Integrated Peer Enhanced System',
                'passed': passed,
                'failed': failed,
                'total': passed + failed,
            })
            
            print(f"\nResult: {passed}/{passed+failed} passed")
            
        except Exception as e:
            print(f"  ✗ Failed: {str(e)}")
            import traceback
            traceback.print_exc()
            self.test_results.append({
                'test': 'Integrated Peer Enhanced System',
                'passed': 0,
                'failed': len(self.formulas_to_test),
                'total': len(self.formulas_to_test),
            })
    
    def print_summary(self):
        """Print test summary"""
        print("\n" + "=" * 80)
        print("TEST SUMMARY")
        print("=" * 80)
        
        total_passed = 0
        total_failed = 0
        total_tests = 0
        
        for result in self.test_results:
            total_passed += result['passed']
            total_failed += result['failed']
            total_tests += result['total']
            
            status = "✓ PASS" if result['failed'] == 0 else "✗ FAIL"
            print(f"\n{status}: {result['test']}")
            print(f"  Passed: {result['passed']}/{result['total']}")
            if result['failed'] > 0:
                print(f"  Failed: {result['failed']}")
        
        print("\n" + "=" * 80)
        print(f"OVERALL: {total_passed}/{total_tests} tests passed ({total_passed/total_tests*100:.1f}%)")
        print("=" * 80)
        
        if total_failed == 0:
            print("\n✓ ALL TESTS PASSED!")
            return True
        else:
            print(f"\n✗ {total_failed} test(s) failed")
            return False


def main():
    """Run all tests"""
    tester = EnhancedSystemTester()
    success = tester.test_all()
    
    # Clean up test files
    test_files = ['test_history.json', 'test_auto_save.json']
    for file in test_files:
        if os.path.exists(file):
            try:
                os.remove(file)
            except:
                pass
    
    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())