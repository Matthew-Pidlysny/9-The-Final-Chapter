"""
Formula History Manager for Peer System
Tracks and manages formula history without modifying original code
"""
import json
import os
from typing import Dict, List, Optional
from datetime import datetime


class FormulaHistoryManager:
    """
    Manages formula history with persistence
    """
    
    def __init__(self, history_file: str = "formula_history.json"):
        """
        Initialize history manager
        
        Args:
            history_file: Path to history file
        """
        self.history_file = history_file
        self.history: List[Dict] = []
        
        # Load existing history
        self._load_history()
    
    def _load_history(self):
        """Load history from file"""
        if os.path.exists(self.history_file):
            try:
                with open(self.history_file, 'r') as f:
                    self.history = json.load(f)
            except Exception as e:
                print(f"Warning: Could not load history: {e}")
                self.history = []
    
    def _save_history(self):
        """Save history to file"""
        try:
            with open(self.history_file, 'w') as f:
                json.dump(self.history, f, indent=2)
        except Exception as e:
            print(f"Warning: Could not save history: {e}")
    
    def save_formula(self, formula: str, result: Dict) -> bool:
        """
        Save a formula to history
        
        Args:
            formula: The formula string
            result: Validation result dictionary
            
        Returns:
            True if saved successfully
        """
        entry = {
            'formula': formula,
            'result': result,
            'timestamp': datetime.now().isoformat(),
        }
        
        # Add to history
        self.history.insert(0, entry)
        
        # Limit history size
        if len(self.history) > 1000:
            self.history = self.history[:1000]
        
        # Save to file
        self._save_history()
        
        return True
    
    def get_history(self, limit: int = 10) -> List[Dict]:
        """
        Get formula history
        
        Args:
            limit: Maximum number of entries to return
            
        Returns:
            List of history entries
        """
        return self.history[:limit]
    
    def search_history(self, query: str) -> List[Dict]:
        """
        Search formula history
        
        Args:
            query: Search query
            
        Returns:
            List of matching entries
        """
        query = query.lower()
        results = []
        
        for entry in self.history:
            if query in entry.get('formula', '').lower():
                results.append(entry)
        
        return results
    
    def clear_history(self) -> bool:
        """Clear all history"""
        self.history = []
        self._save_history()
        return True
    
    def get_stats(self) -> Dict:
        """Get history statistics"""
        total = len(self.history)
        valid = sum(1 for e in self.history if e.get('result', {}).get('is_valid'))
        invalid = total - valid
        
        return {
            'total': total,
            'valid': valid,
            'invalid': invalid,
            'success_rate': (valid / total * 100) if total > 0 else 0,
        }


if __name__ == "__main__":
    # Test history manager
    manager = FormulaHistoryManager()
    
    # Add some test entries
    test_formulas = [
        ("F = ma", {'is_valid': True}),
        ("E = mc^2", {'is_valid': True}),
        ("∫ x^2 dx", {'is_valid': False, 'errors': ['Missing constant']}),
    ]
    
    print("Testing Formula History Manager")
    print("=" * 60)
    
    for formula, result in test_formulas:
        manager.save_formula(formula, result)
        print(f"Saved: {formula}")
    
    print("\nHistory:")
    print("-" * 60)
    for entry in manager.get_history(5):
        print(f"{entry['timestamp']}: {entry['formula']}")
    
    print("\nStatistics:")
    print("-" * 60)
    stats = manager.get_stats()
    for key, value in stats.items():
        print(f"{key}: {value}")