"""
Peer Enhanced Main Entry Point
Gentle merge approach - imports and extends existing Peer functionality
without modifying original code
"""
import sys
import os

# Add current directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import original Peer (preserved, not modified)
try:
    from peer import Peer
    ORIGINAL_PEER_AVAILABLE = True
except ImportError:
    print("Warning: Original Peer module not available")
    ORIGINAL_PEER_AVAILABLE = False
    Peer = None

# Import enhanced components (new modules)
from ui_enhanced_components import EnhancedUIManager
from validation_enhanced import EnhancedValidationEngine
from scientific_improvements_lookup import ScientificImprovementEngine
from formula_history_manager import FormulaHistoryManager
from template_manager import TemplateManager
from formula_preview_panel import FormulaPreviewPanel
from auto_save_manager import AutoSaveManager
from export_import_manager import ExportImportManager


class PeerEnhanced:
    """
    Enhanced Peer system that wraps and extends original Peer functionality
    Gentle merge approach - original code remains untouched
    """
    
    def __init__(self):
        """Initialize enhanced Peer system"""
        self.original_peer = None
        self.ui_manager = None
        self.validation_engine = None
        self.improvements_engine = None
        self.history_manager = None
        self.template_manager = None
        self.preview_panel = None
        self.auto_save_manager = None
        self.export_import_manager = None
        
        # Initialize components
        self._initialize_components()
    
    def _initialize_components(self):
        """Initialize all enhanced components"""
        print("Initializing Peer Enhanced System...")
        
        # Initialize scientific improvements engine
        self.improvements_engine = ScientificImprovementEngine()
        print("✓ Scientific Improvements Engine loaded")
        
        # Initialize validation engine with improvements
        self.validation_engine = EnhancedValidationEngine(
            improvements_engine=self.improvements_engine
        )
        print("✓ Enhanced Validation Engine loaded")
        
        # Initialize history manager
        self.history_manager = FormulaHistoryManager()
        print("✓ Formula History Manager loaded")
        
        # Initialize template manager
        self.template_manager = TemplateManager()
        print("✓ Template Manager loaded")
        
        # Initialize preview panel
        self.preview_panel = FormulaPreviewPanel()
        print("✓ Formula Preview Panel loaded")
        
        # Initialize auto-save manager
        self.auto_save_manager = AutoSaveManager()
        print("✓ Auto-Save Manager loaded")
        
        # Initialize export/import manager
        self.export_import_manager = ExportImportManager()
        print("✓ Export/Import Manager loaded")
        
        # Initialize UI manager
        self.ui_manager = EnhancedUIManager(
            validation_engine=self.validation_engine,
            improvements_engine=self.improvements_engine,
            history_manager=self.history_manager,
            template_manager=self.template_manager,
            preview_panel=self.preview_panel,
            auto_save_manager=self.auto_save_manager,
            export_import_manager=self.export_import_manager
        )
        print("✓ Enhanced UI Manager loaded")
        
        # Try to initialize original Peer (if available)
        if ORIGINAL_PEER_AVAILABLE and Peer:
            try:
                self.original_peer = Peer()
                print("✓ Original Peer system loaded (preserved)")
            except Exception as e:
                print(f"Warning: Could not initialize original Peer: {e}")
        
        print("\n" + "="*60)
        print("Peer Enhanced System Ready!")
        print("="*60)
    
    def validate_formula(self, formula: str) -> dict:
        """
        Validate a formula with enhanced features
        
        Args:
            formula: The formula string to validate
            
        Returns:
            Dictionary with validation results and improvements
        """
        result = {
            'formula': formula,
            'is_valid': False,
            'errors': [],
            'warnings': [],
            'improvements': [],
            'suggestions': [],
            'scientific_domain': None,
            'timestamp': None,
        }
        
        try:
            # Get validation from enhanced engine
            validation_result = self.validation_engine.validate(formula)
            result.update(validation_result)
            
            # Get scientific improvements
            improvements = self.improvements_engine.analyze_formula(formula)
            result['improvements'] = improvements.get('suggestions', [])
            result['scientific_domain'] = improvements.get('detected_domains', [])
            
            # Save to history
            self.history_manager.save_formula(formula, result)
            
            # Trigger auto-save
            self.auto_save_manager.save(formula, result)
            
        except Exception as e:
            result['errors'].append(f"Validation error: {str(e)}")
        
        return result
    
    def get_template(self, template_name: str) -> dict:
        """Get a formula template"""
        return self.template_manager.get_template(template_name)
    
    def get_all_templates(self) -> list:
        """Get all available templates"""
        return self.template_manager.list_templates()
    
    def get_history(self, limit: int = 10) -> list:
        """Get formula history"""
        return self.history_manager.get_history(limit)
    
    def export_formula(self, formula: dict, format: str = 'json') -> str:
        """Export formula in specified format"""
        return self.export_import_manager.export(formula, format)
    
    def import_formula(self, data: str, format: str = 'json') -> dict:
        """Import formula from specified format"""
        return self.export_import_manager.import_formula(data, format)
    
    def get_preview(self, formula: str, render_format: str = 'latex') -> str:
        """Get rendered formula preview"""
        return self.preview_panel.render(formula, render_format)
    
    def get_stuck_help(self, formula: str) -> dict:
        """Get help for stuck user"""
        from stuck_button_assistant import StuckButtonAssistant
        
        assistant = StuckButtonAssistant()
        return assistant.analyze_and_help(formula)
    
    def run(self):
        """Run the enhanced Peer system"""
        print("\nPeer Enhanced System")
        print("=" * 60)
        print("Enhanced with:")
        print("  • 300 major improvements")
        print("  • 5000+ scientific improvement suggestions")
        print("  • Interactive tutorial system")
        print("  • Modern UI components")
        print("  • Auto-save and history")
        print("  • Templates and quick actions")
        print("  • Multi-format export/import")
        print("=" * 60)
        print("\nStarting enhanced UI...")
        
        # Launch enhanced UI
        if self.ui_manager:
            self.ui_manager.run()
        else:
            print("Error: UI manager not initialized")


def main():
    """Main entry point"""
    peer_enhanced = PeerEnhanced()
    peer_enhanced.run()


if __name__ == "__main__":
    main()