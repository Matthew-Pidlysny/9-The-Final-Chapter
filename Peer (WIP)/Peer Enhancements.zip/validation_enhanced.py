"""
Enhanced Validation Engine for Peer System
Gentle merge approach - extends validation capabilities without modifying original code
"""
import re
from typing import Dict, List, Optional, Tuple
from datetime import datetime


class EnhancedValidationEngine:
    """
    Enhanced validation engine with scientific improvements integration
    """
    
    def __init__(self, improvements_engine=None):
        """
        Initialize enhanced validation engine
        
        Args:
            improvements_engine: ScientificImprovementEngine instance
        """
        self.improvements_engine = improvements_engine
        
        # Validation patterns
        self.patterns = self._build_validation_patterns()
        
        # Common errors
        self.common_errors = self._build_common_errors()
    
    def _build_validation_patterns(self) -> Dict[str, List[str]]:
        """Build regex patterns for validation"""
        return {
            'mathematical': [
                r'^[a-zA-Z0-9+\-*/^=().,\s]+$',  # Basic math
                r'\b(sin|cos|tan|log|ln|sqrt|exp)\b',  # Functions
                r'\b(pi|e|phi)\b',  # Constants
            ],
            'physics': [
                r'\b(F|E|P|W|Q|m|a|v|t|T|V|I|R|C|L)\b',  # Physics variables
                r'\b(g|c|h|k|G|ε|μ|σ)\b',  # Physics constants
            ],
            'chemistry': [
                r'\b(n|V|P|T|R)\b',  # Gas law variables
                r'\b(K_a|K_b|K_w|pH|pOH)\b',  # Chemistry constants
            ],
            'calculus': [
                r'\b(d/d[a-z]|∂/∂[a-z])\b',  # Derivatives
                r'∫',  # Integral
                r'\b(limit|lim)\b',  # Limits
            ],
            'statistics': [
                r'\b(mean|median|mode|std|var|cov)\b',  # Stats functions
                r'\b(μ|σ|α|β|γ)\b',  # Greek letters
            ],
        }
    
    def _build_common_errors(self) -> List[Dict]:
        """Build list of common formula errors"""
        return [
            {
                'pattern': r'/\s*\)',
                'message': 'Missing opening parenthesis for division',
                'severity': 'high',
            },
            {
                'pattern': r'\(\s*[/+\-*]\s*',
                'message': 'Empty parentheses',
                'severity': 'high',
            },
            {
                'pattern': r'[+\-*/]{2,}',
                'message': 'Multiple consecutive operators',
                'severity': 'medium',
            },
            {
                'pattern': r'=\s*=',
                'message': 'Double equals sign',
                'severity': 'high',
            },
            {
                'pattern': r'\d\s+[a-zA-Z]',
                'message': 'Missing multiplication operator between number and variable',
                'severity': 'medium',
            },
            {
                'pattern': r'[a-zA-Z]\s+\d',
                'message': 'Missing multiplication operator between variable and number',
                'severity': 'medium',
            },
        ]
    
    def validate(self, formula: str) -> Dict:
        """
        Validate a formula comprehensively
        
        Args:
            formula: The formula string to validate
            
        Returns:
            Dictionary with validation results
        """
        result = {
            'formula': formula,
            'is_valid': True,
            'errors': [],
            'warnings': [],
            'suggestions': [],
            'scientific_domain': [],
            'timestamp': datetime.now().isoformat(),
        }
        
        # Basic checks
        if not formula or not formula.strip():
            result['is_valid'] = False
            result['errors'].append("Formula is empty")
            return result
        
        # Strip whitespace
        formula = formula.strip()
        
        # Check for common errors
        self._check_common_errors(formula, result)
        
        # Check syntax
        self._check_syntax(formula, result)
        
        # Detect domain
        domains = self._detect_domain(formula)
        result['scientific_domain'] = domains
        
        # Domain-specific validation
        for domain in domains:
            self._validate_domain(formula, domain, result)
        
        # Get scientific improvements if engine available
        if self.improvements_engine:
            improvements = self.improvements_engine.analyze_formula(formula)
            result['improvements'] = improvements.get('suggestions', [])
            result['high_priority_issues'] = improvements.get('high_priority_issues', [])
        
        # Determine overall validity
        if result['errors']:
            result['is_valid'] = False
        
        return result
    
    def _check_common_errors(self, formula: str, result: Dict):
        """Check for common formula errors"""
        for error in self.common_errors:
            if re.search(error['pattern'], formula):
                message = error['message']
                if error['severity'] == 'high':
                    result['errors'].append(message)
                    result['is_valid'] = False
                else:
                    result['warnings'].append(message)
    
    def _check_syntax(self, formula: str, result: Dict):
        """Check formula syntax"""
        # Check balanced parentheses
        if formula.count('(') != formula.count(')'):
            result['errors'].append("Unbalanced parentheses")
            result['is_valid'] = False
        
        # Check balanced brackets
        if formula.count('[') != formula.count(']'):
            result['errors'].append("Unbalanced brackets")
            result['is_valid'] = False
        
        # Check balanced braces
        if formula.count('{') != formula.count('}'):
            result['errors'].append("Unbalanced braces")
            result['is_valid'] = False
        
        # Check for unmatched quotes
        if formula.count('"') % 2 != 0:
            result['errors'].append("Unmatched quotes")
            result['is_valid'] = False
        
        # Check for invalid characters (basic)
        invalid_chars = re.findall(r'[^\w+\-*/^=().,\s\[\]{}"\'∫∂∑∏√±]', formula)
        if invalid_chars:
            unique_invalid = set(invalid_chars)
            result['warnings'].append(
                f"Potentially invalid characters: {', '.join(unique_invalid)}"
            )
    
    def _detect_domain(self, formula: str) -> List[str]:
        """Detect scientific domain(s) of formula"""
        detected = []
        
        for domain, patterns in self.patterns.items():
            for pattern in patterns:
                if re.search(pattern, formula, re.IGNORECASE):
                    if domain not in detected:
                        detected.append(domain)
                    break
        
        return detected
    
    def _validate_domain(self, formula: str, domain: str, result: Dict):
        """Validate formula for specific domain"""
        
        if domain == 'calculus':
            self._validate_calculus(formula, result)
        elif domain == 'mathematical':
            self._validate_mathematical(formula, result)
        elif domain == 'physics':
            self._validate_physics(formula, result)
        elif domain == 'chemistry':
            self._validate_chemistry(formula, result)
        elif domain == 'statistics':
            self._validate_statistics(formula, result)
    
    def _validate_calculus(self, formula: str, result: Dict):
        """Validate calculus formulas"""
        # Check for integration constant
        if '∫' in formula and 'C' not in formula and '+ C' not in formula:
            result['warnings'].append(
                "Indefinite integral might be missing the constant of integration (+ C)"
            )
        
        # Check for chain rule
        if 'd/dx' in formula or '∂/∂' in formula:
            if '(' not in formula:
                result['warnings'].append(
                    "Derivative might need chain rule application for composite functions"
                )
        
        # Check for improper integrals
        if '∫' in formula and ('∞' in formula or 'infinity' in formula.lower()):
            result['suggestions'].append(
                "Verify convergence of improper integral before evaluating"
            )
    
    def _validate_mathematical(self, formula: str, result: Dict):
        """Validate mathematical formulas"""
        # Check for domain restrictions
        if '/' in formula:
            result['suggestions'].append(
                "Verify denominator is not zero"
            )
        
        # Check for square roots
        if 'sqrt' in formula or '√' in formula:
            result['suggestions'].append(
                "Ensure radicand (expression under square root) is non-negative"
            )
        
        # Check for logarithms
        if re.search(r'\blog\b|ln\b', formula):
            result['suggestions'].append(
                "Ensure argument of logarithm is positive"
            )
    
    def _validate_physics(self, formula: str, result: Dict):
        """Validate physics formulas"""
        # Check for unit consistency
        result['suggestions'].append(
            "Verify unit consistency (use SI units: m, kg, s, etc.)"
        )
        
        # Check for vector notation
        physics_vectors = ['F', 'v', 'a', 'p', 'E', 'B']
        for var in physics_vectors:
            if f'{var}=' in formula or f'{var} =' in formula:
                result['suggestions'].append(
                    f"Consider if '{var}' should be a vector quantity"
                )
        
        # Check for energy conservation
        if 'E=' in formula or 'E =' in formula:
            result['suggestions'].append(
                "Verify energy conservation principles apply"
            )
    
    def _validate_chemistry(self, formula: str, result: Dict):
        """Validate chemistry formulas"""
        # Check for gas law
        if 'PV=' in formula or 'PV =' in formula:
            result['suggestions'].append(
                "Ensure P (pressure) and V (volume) use consistent units"
            )
        
        # Check for stoichiometry
        if '+' in formula and '→' not in formula and '=' not in formula:
            result['warnings'].append(
                "Chemical equation should use → or = for reactions"
            )
    
    def _validate_statistics(self, formula: str, result: Dict):
        """Validate statistical formulas"""
        # Check for sample vs population
        if 'mean' in formula.lower() or 'μ' in formula:
            result['suggestions'].append(
                "Clarify if calculating sample mean (x̄) or population mean (μ)"
            )
        
        # Check for standard deviation
        if 'std' in formula.lower() or 'σ' in formula:
            result['suggestions'].append(
                "Clarify if calculating sample std (s) or population std (σ)"
            )


class FormulaSimplifier:
    """
    Formula simplification and normalization utilities
    """
    
    @staticmethod
    def normalize(formula: str) -> str:
        """Normalize formula format"""
        # Remove extra spaces
        formula = re.sub(r'\s+', ' ', formula)
        formula = formula.strip()
        
        # Normalize multiplication
        formula = re.sub(r'(\d)\s*([a-zA-Z])', r'\1*\2', formula)
        formula = re.sub(r'([a-zA-Z])\s*(\d)', r'\1*\2', formula)
        
        # Normalize powers
        formula = re.sub(r'\^', '**', formula)
        
        return formula
    
    @staticmethod
    def format_latex(formula: str) -> str:
        """Convert formula to LaTeX format"""
        # Replace common operators
        formula = formula.replace('∫', r'\int')
        formula = formula.replace('∂', r'\partial')
        formula = formula.replace('√', r'\sqrt')
        formula = formula.replace('∞', r'\infty')
        formula = formula.replace('±', r'\pm')
        
        return formula
    
    @staticmethod
    def extract_variables(formula: str) -> List[str]:
        """Extract variable names from formula"""
        # Find all variable names (single letters or words)
        variables = re.findall(r'\b[a-zA-Z]\w*\b', formula)
        
        # Remove common functions
        functions = ['sin', 'cos', 'tan', 'log', 'ln', 'sqrt', 'exp', 'mean', 'std', 'var']
        variables = [v for v in variables if v not in functions]
        
        return sorted(list(set(variables)))


if __name__ == "__main__":
    # Test the validation engine
    engine = EnhancedValidationEngine()
    
    test_formulas = [
        "F = ma",
        "E = mc^2",
        "∫ x^2 dx",
        "PV = nRT",
        "μ = (x1 + x2 + x3) / 3",
    ]
    
    print("=" * 60)
    print("Enhanced Validation Engine Test")
    print("=" * 60)
    
    for formula in test_formulas:
        print(f"\nValidating: {formula}")
        print("-" * 60)
        
        result = engine.validate(formula)
        
        print(f"Valid: {result['is_valid']}")
        print(f"Domain: {', '.join(result['scientific_domain'])}")
        
        if result['errors']:
            print(f"Errors: {len(result['errors'])}")
            for error in result['errors']:
                print(f"  - {error}")
        
        if result['warnings']:
            print(f"Warnings: {len(result['warnings'])}")
            for warning in result['warnings']:
                print(f"  - {warning}")
        
        if result['suggestions']:
            print(f"Suggestions: {len(result['suggestions'])}")
            for suggestion in result['suggestions']:
                print(f"  - {suggestion}")