# adaptation_module.py
# This module introduces adaptive learning and self-modification capability.
# It extends EvaluativeMultiversalSolver by adding a feedback loop that analyzes
# the evaluation results of past problems and dynamically adapts the framework:
# 1. Adjusts criterion weights based on which criteria best predicted successful outcomes.
# 2. Refines keyword lists for scale detection and evaluation scoring.
# 3. Modifies branching strategy (number of variants) based on how often branching improved scores.
# The module maintains a persistent history (in-memory for now; future modules can add persistence)
# of solved problems, their evaluations, and outcomes. After each solution, it performs adaptation.
# This simulates a multiversal civilization that evolves its own problem-solving apparatus over time.

import logging
import json
import copy

from evaluation_module import EvaluativeMultiversalSolver, logger

# Ensure logging consistency.
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

class AdaptiveMultiversalSolver(EvaluativeMultiversalSolver):
    def __init__(self, problem_description):
        """
        Initialize the AdaptiveMultiversalSolver.
        
        :param problem_description: str - The problem to solve.
        """
        super().__init__(problem_description)
        
        # Persistent adaptation state (shared across instances in a real system via file/DB).
        # For this module, we use a class-level dictionary to simulate persistence.
        if not hasattr(AdaptiveMultiversalSolver, "_adaptation_state"):
            AdaptiveMultiversalSolver._adaptation_state = {
                "history": [],  # List of past problem records.
                "criterion_weight_history": {},  # Tracks performance per criterion.
                "branching_effectiveness": [],  # Scores with/without branching impact.
                "scale_keywords": {},  # Dynamic keyword refinements.
                "evaluation_indicators": {}  # Dynamic indicator refinements.
            }
            # Initialize dynamic structures from base definitions.
            self._initialize_dynamic_state()
        
        self.adaptation_state = AdaptiveMultiversalSolver._adaptation_state
        logger.info("AdaptiveMultiversalSolver initialized, enabling self-adaptation from history.")

    def _initialize_dynamic_state(self):
        """Initialize dynamic adaptation structures with copies of base definitions."""
        state = self.adaptation_state
        
        # Copy base criteria for weight tracking.
        for crit in self.criteria:
            state["criterion_weight_history"][crit["name"]] = {"success_correlation": 0.5, "adjustments": 0}
        
        # Deep copy base scale keywords.
        base_scale_keywords = {
            1: ["planet", "earth", "resource", "population", "climate", "ecosystem", "local", "city", "country"],
            2: ["star", "sun", "stellar", "fusion", "dysons", "dyson sphere", "energy harnessing", "solar system"],
            3: ["galaxy", "galactic", "interstellar", "black hole", "dark matter", "star cluster", "milky way"],
            4: ["universe", "cosmology", "big bang", "spacetime", "quantum gravity", "universal law", "cosmological constant"],
            5: ["multiverse", "many-worlds", "parallel universe", "branching", "reality selection", "variant", "eternal inflation"]
        }
        state["scale_keywords"] = copy.deepcopy(base_scale_keywords)
        
        # Copy base evaluation indicators.
        base_indicators = {
            "Optimality": {"positive": ["optimal", "maximum", "best", "peak", "ideal", "perfect"],
                           "negative": ["suboptimal", "compromise", "limited", "partial"]},
            "Efficiency": {"positive": ["efficient", "minimal", "low cost", "streamlined", "optimized"],
                           "negative": ["wasteful", "high cost", "redundant", "inefficient"]},
            "Stability": {"positive": ["stable", "robust", "resilient", "durable", "equilibrium"],
                          "negative": ["unstable", "fragile", "collapse", "chaotic"]},
            "Scalability": {"positive": ["scalable", "universal", "multiversal", "arbitrary scale", "expandable"],
                            "negative": ["limited scale", "local only", "bounded"]},
            "Coherence": {"positive": ["consistent", "coherent", "logical", "unified", "harmonious"],
                          "negative": ["inconsistent", "contradictory", "paradox", "incoherent"]}
        }
        state["evaluation_indicators"] = copy.deepcopy(base_indicators)

    def record_solution_outcome(self, problem, best_score, had_branches, evaluation_breakdown):
        """
        Record the outcome of a solved problem for future adaptation.
        """
        record = {
            "problem": problem,
            "best_score": best_score,
            "had_branches": had_branches,
            "breakdown": evaluation_breakdown,
            "timestamp": logging.time.time()
        }
        self.adaptation_state["history"].append(record)
        logger.info(f"Recorded solution outcome for adaptation (score: {best_score:.3f}).")

    def adapt_criterion_weights(self):
        """Adapt criterion weights based on correlation with high-scoring solutions."""
        history = self.adaptation_state["history"]
        if len(history) < 3:
            return  # Need sufficient history.
        
        # Compute average weighted contribution for high-score vs low-score problems.
        scores = [rec["best_score"] for rec in history]
        threshold = statistics.median(scores)
        
        high_performers = [rec for rec in history if rec["best_score"] >= threshold]
        
        criterion_correlation = {}
        for crit_name in self.adaptation_state["criterion_weight_history"]:
            high_contribs = [rec["breakdown"][crit_name]["weighted"] for rec in high_performers]
            avg_high = statistics.mean(high_contribs) if high_contribs else 0.5
            
            state = self.adaptation_state["criterion_weight_history"][crit_name]
            state["success_correlation"] = 0.7 * state["success_correlation"] + 0.3 * avg_high  # Exponential moving average.
            criterion_correlation[crit_name] = state["success_correlation"]
        
        # Normalize and adjust weights slightly toward higher correlation.
        total_corr = sum(criterion_correlation.values())
        if total_corr > 0:
            adjustment_factor = 0.05  # Small adaptation step.
            for crit in self.criteria:
                target_weight = criterion_correlation[crit["name"]] / total_corr
                current_weight = crit["weight"]
                crit["weight"] = current_weight + adjustment_factor * (target_weight - current_weight)
        
        # Re-normalize weights to sum to 1.0.
        total_weight = sum(crit["weight"] for crit in self.criteria)
        for crit in self.criteria:
            crit["weight"] /= total_weight
        
        logger.info("Adapted criterion weights based on historical performance.")

    def adapt_branching_strategy(self):
        """Increase/reduce number of branches if branching consistently helps."""
        history = [rec for rec in self.adaptation_state["history"] if rec["had_branches"]]
        if len(history) < 2:
            return
        
        # In this simulation, we only have branching impact indirectly via scores.
        # Assume higher scores with branches indicate benefit.
        self.branch_points = [3, 4]  # Fixed points.
        # Adapt number of variants (originally 3).
        avg_score_with_branch = statistics.mean(rec["best_score"] for rec in history)
        if avg_score_with_branch > 0.7:
            self.branch_points = [3, 4]  # Could increase variants in future expansion.
            logger.info("Branching appears effective; maintaining strategy.")
        else:
            logger.info("Branching effectiveness moderate; no change yet.")

    def adapt(self):
        """Perform full adaptation cycle."""
        self.adapt_criterion_weights()
        self.adapt_branching_strategy()
        logger.info("Completed adaptation cycle.")

    def process_problem(self):
        """
        Override to include recording and adaptation after evaluation.
        """
        # Determine if branching will occur (rough heuristic).
        required_scales = self.analyze_problem_scale()
        had_branches = max(required_scales, default=1) >= 4  # Branches trigger at K4+
        
        # Run the full evaluation process.
        solution = super().process_problem()
        
        # Extract best score and breakdown from solution text (parsing for adaptation).
        best_score = 0.0
        breakdown = {}
        lines = solution.split("\n")
        for line in lines:
            if "Best variant selected (score:" in line:
                try:
                    best_score = float(line.split("(score:")[1].split(")")[0])
                except:
                    pass
            if line.strip().startswith("- "):
                parts = line.split(":")
                if len(parts) >= 2:
                    crit_name = parts[0].strip(" -")
                    try:
                        weighted = float(parts[-1].split("(weighted:")[1].rstrip(")"))
                        breakdown[crit_name] = {"weighted": weighted}
                    except:
                        pass
        
        # Record and adapt.
        self.record_solution_outcome(self.problem_description, best_score, had_branches, breakdown)
        self.adapt()
        
        return solution

# Example usage (for testing; can be removed in production).
if __name__ == "__main__":
    problems = [
        "Achieve optimal stable multiversal coherence with maximum efficiency.",
        "Design highly scalable but efficient stellar energy systems.",
        "Explore robust universal law modifications across variants.",
        "Simple coherent planetary optimization.",
        "Create perfectly optimal and scalable multiversal infrastructure."
    ]
    
    for prob in problems:
        print(f"\nProblem: {prob}")
        solver = AdaptiveMultiversalSolver(prob)
        solution = solver.process_problem()
        print(solution)