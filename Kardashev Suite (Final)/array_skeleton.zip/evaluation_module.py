# evaluation_module.py
# This module adds evaluation and selection of the best solution paths.
# It extends BranchingMultiversalSolver by introducing a quantitative evaluation
# mechanism for each branch outcome. After branching and recombination,
# it scores each variant based on explicit criteria (optimality, efficiency,
# stability, scalability, and multiversal coherence). The highest-scoring
# branch is selected as the primary solution, while others are retained
# as alternatives. This simulates a multiversal civilization's ability to
# rigorously evaluate and choose the optimal reality path from many variants.
# Evaluation metrics are fully declared and weighted for transparency and
# future extensibility (e.g., adding domain-specific metrics).

import logging
import re
import statistics

from branching_module import BranchingMultiversalSolver, logger

# Ensure logging consistency.
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

class EvaluativeMultiversalSolver(BranchingMultiversalSolver):
    def __init__(self, problem_description):
        """
        Initialize the EvaluativeMultiversalSolver.
        
        :param problem_description: str - The problem to solve.
        """
        super().__init__(problem_description)
        
        # Define evaluation criteria with weights (sum to 1.0 for normalized scoring).
        # Each criterion has a name, weight, and a scoring function that takes output text and returns 0-1 score.
        self.criteria = [
            {"name": "Optimality",       "weight": 0.25, "desc": "Degree to which the solution achieves maximum benefit."},
            {"name": "Efficiency",       "weight": 0.20, "desc": "Resource and computational efficiency."},
            {"name": "Stability",        "weight": 0.20, "desc": "Robustness against perturbations."},
            {"name": "Scalability",      "weight": 0.15, "desc": "Ability to apply at higher scales."},
            {"name": "Coherence",        "weight": 0.20, "desc": "Logical and multiversal consistency."},
        ]
        
        logger.info("EvaluativeMultiversalSolver initialized, adding branch evaluation and selection.")

    def score_criterion(self, criterion_name, output_text):
        """
        Score a single criterion on a 0-1 scale based on heuristic keyword presence and patterns.
        Fully declared, no placeholders. Easily extensible by adding more rules.
        
        :param criterion_name: str - Name of the criterion.
        :param output_text: str - The branch output to score.
        :return: float - Score between 0 and 1.
        """
        text = output_text.lower()
        
        # Define positive and negative indicators per criterion.
        indicators = {
            "Optimality": {
                "positive": ["optimal", "maximum", "best", "peak", "ideal", "perfect"],
                "negative": ["suboptimal", "compromise", "limited", "partial"]
            },
            "Efficiency": {
                "positive": ["efficient", "minimal", "low cost", "streamlined", "optimized"],
                "negative": ["wasteful", "high cost", "redundant", "inefficient"]
            },
            "Stability": {
                "positive": ["stable", "robust", "resilient", "durable", "equilibrium"],
                "negative": ["unstable", "fragile", "collapse", "chaotic"]
            },
            "Scalability": {
                "positive": ["scalable", "universal", "multiversal", "arbitrary scale", "expandable"],
                "negative": ["limited scale", "local only", "bounded"]
            },
            "Coherence": {
                "positive": ["consistent", "coherent", "logical", "unified", "harmonious"],
                "negative": ["inconsistent", "contradictory", "paradox", "incoherent"]
            }
        }
        
        rules = indicators.get(criterion_name, {"positive": [], "negative": []})
        pos_count = sum(len(re.findall(r'\b' + re.escape(word) + r'\b', text)) for word in rules["positive"])
        neg_count = sum(len(re.findall(r'\b' + re.escape(word) + r'\b', text)) for word in rules["negative"])
        
        # Simple heuristic score: favor positives, penalize negatives.
        if pos_count + neg_count == 0:
            return 0.5  # Neutral if no indicators.
        
        score = pos_count / (pos_count + neg_count + 1)  # +1 to avoid division by zero and soften.
        return min(1.0, score * 1.2)  # Slight boost for strong positives, capped at 1.

    def evaluate_branch(self, branch_output):
        """
        Evaluate a single branch output across all criteria.
        
        :param branch_output: str - The full output text of a branch.
        :return: tuple - (total_score: float, breakdown: dict)
        """
        breakdown = {}
        total_score = 0.0
        
        for crit in self.criteria:
            crit_score = self.score_criterion(crit["name"], branch_output)
            weighted = crit_score * crit["weight"]
            breakdown[crit["name"]] = {"score": crit_score, "weighted": weighted}
            total_score += weighted
        
        logger.info(f"Branch evaluated with total score {total_score:.3f}: {breakdown}")
        return total_score, breakdown

    def process_problem(self):
        """
        Override to add evaluation after branching.
        Executes the full branching process, then evaluates each variant.
        Selects the best, reports alternatives, and constructs a final evaluated solution.
        
        :return: str - The evaluated and selected multiversal solution.
        """
        # Get the raw branching result first.
        raw_solution = super().process_problem()
        
        # Parse branches from the branching output.
        # Expected format has "Parallel variants:" section with | separated branches.
        branches = []
        if "Parallel variants:" in raw_solution:
            variants_part = raw_solution.split("Parallel variants:")[1].strip()
            branches = [v.strip() for v in variants_part.split("|")]
        elif "no branches triggered" in raw_solution:
            # Fallback: treat the common path as single branch.
            common_part = raw_solution.split("(no branches triggered):")[1].strip()
            branches = [common_part]
        
        if not branches:
            solution = "Evaluated solution: No branches to evaluate.\n" + raw_solution
            return solution
        
        # Evaluate each branch.
        evaluations = []
        for branch in branches:
            score, breakdown = self.evaluate_branch(branch)
            evaluations.append((score, branch, breakdown))
        
        # Sort by score descending.
        evaluations.sort(key=lambda x: x[0], reverse=True)
        
        best_score, best_branch, best_breakdown = evaluations[0]
        
        # Build detailed report.
        report_lines = [
            "Evaluative multiversal solution:",
            f"Best variant selected (score: {best_score:.3f}):",
            f"{best_branch}",
            "",
            "Evaluation breakdown for best variant:"
        ]
        for name, data in best_breakdown.items():
            report_lines.append(f"  - {name}: {data['score']:.2f} (weighted: {data['weighted']:.3f})")
        
        if len(evaluations) > 1:
            report_lines.append("")
            report_lines.append("Alternative variants (lower scores):")
            for score, branch, _ in evaluations[1:]:
                report_lines.append(f"  Score {score:.3f}: {branch}")
        
        solution = "\n".join(report_lines)
        logger.info("Final evaluated solution constructed.")
        return solution

# Example usage (for testing; can be removed in production).
if __name__ == "__main__":
    problems = [
        "Design an optimal and stable multiversal energy network with high efficiency.",
        "Explore scalable but potentially unstable universal constant variations across realities.",
        "Create a coherent and robust infrastructure for interstellar expansion.",
        "Simple planetary problem with minimal variants."
    ]
    
    for prob in problems:
        print(f"\nProblem: {prob}")
        solver = EvaluativeMultiversalSolver(prob)
        solution = solver.process_problem()
        print(solution)