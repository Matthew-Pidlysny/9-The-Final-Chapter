# recursion_module.py
# This module introduces recursive self-application: the framework can now treat
# its own solution-generating process as a problem to be solved at a higher scale.
# It extends IntegrationMultiversalSolver by adding a recursion capability where,
# after producing a solution, the solver can optionally feed that solution back
# into itself as a new problem at the next Kardashev scale (or K5 if already max).
# This enables iterative refinement, meta-optimization, and true self-improvement
# — the hallmark of a mature multiversal civilization that solves not just the
# original problem but the optimal way to solve problems of that class.
# Recursion depth is controlled to prevent infinite loops, with convergence
# checked via solution score improvement. The final output includes the full
# recursive refinement history.

import logging

from integration_module import IntegrationMultiversalSolver, logger

# Ensure logging consistency.
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

class RecursiveMultiversalSolver(IntegrationMultiversalSolver):
    def __init__(self, problem_description, max_recursion_depth=3, improvement_threshold=0.05):
        """
        Initialize the RecursiveMultiversalSolver.
        
        :param problem_description: str - The initial problem to solve.
        :param max_recursion_depth: int - Maximum allowed recursion levels (default 3).
        :param improvement_threshold: float - Minimum score improvement required to continue recursing.
        """
        super().__init__(problem_description)
        self.max_recursion_depth = max_recursion_depth
        self.improvement_threshold = improvement_threshold
        self.recursion_history = []  # Stores (depth, problem, solution, score)
        logger.info(f"RecursiveMultiversalSolver initialized with max depth {max_recursion_depth}.")

    def extract_best_score_from_solution(self, solution_text):
        """
        Parse the best score from the solution string (robust to format changes).
        """
        lines = solution_text.split("\n")
        for line in lines:
            if "Best variant selected (score:" in line:
                try:
                    score_str = line.split("(score:")[1].split(")")[0].strip()
                    return float(score_str)
                except:
                    pass
        return 0.0  # Fallback if not found.

    def generate_meta_problem(self, current_solution, current_scale):
        """
        Generate a higher-level meta-problem from the current solution.
        Promotes the solution process to the next scale for optimization.
        """
        meta_prompts = {
            1: "Optimize the planetary-scale solution for higher efficiency and generality.",
            2: "Elevate the stellar-scale solution to galactic coordination principles.",
            3: "Integrate the galactic solution into universal physical laws.",
            4: "Refine the universal solution through multiversal variant selection.",
            5: "Meta-optimize the entire multiversal solution process itself for superior outcomes."
        }
        next_scale = min(current_scale + 1, 5)
        base_meta = meta_prompts.get(next_scale, meta_prompts[5])
        meta_problem = f"[Recursive Refinement Level -> K{next_scale}] {base_meta}\nBase solution to improve:\n{current_solution}"
        return meta_problem

    def solve_with_recursion(self, problem, depth=0, previous_score=0.0):
        """
        Recursively solve the problem, with convergence control.
        """
        if depth >= self.max_recursion_depth:
            logger.info(f"Maximum recursion depth {self.max_recursion_depth} reached.")
            return None, previous_score
        
        # Temporarily set the current problem for this recursive call.
        self.problem_description = problem
        
        # Re-initialize skeletons to re-apply integrations and selections for the new problem.
        self.skeleton_array = []
        self.initialize_skeleton_array()
        
        # Solve the (meta-)problem.
        solution = self.process_problem()
        current_score = self.extract_best_score_from_solution(solution)
        
        # Record in history.
        estimated_scale = max(self.analyze_problem_scale(), default=1)
        self.recursion_history.append({
            "depth": depth,
            "problem": problem,
            "scale": estimated_scale,
            "solution": solution,
            "score": current_score
        })
        
        logger.info(f"Recursion depth {depth}: score {current_score:.3f} (previous: {previous_score:.3f})")
        
        # Check for convergence/improvement.
        if depth > 0:
            improvement = current_score - previous_score
            if improvement < self.improvement_threshold:
                logger.info(f"Improvement {improvement:.3f} below threshold {self.improvement_threshold}; converging.")
                return solution, current_score
        
        # Generate meta-problem and recurse.
        meta_problem = self.generate_meta_problem(solution, estimated_scale)
        refined_solution, final_score = self.solve_with_recursion(meta_problem, depth + 1, current_score)
        
        if refined_solution is not None:
            return refined_solution, final_score
        
        return solution, current_score

    def process_problem(self):
        """
        Override the main entry point to enable full recursive solving.
        """
        logger.info("Starting recursive multiversal solution process.")
        final_solution, final_score = self.solve_with_recursion(self.problem_description, depth=0)
        
        # Build comprehensive recursive report.
        report_lines = [
            "Recursive Multiversal Solution Complete",
            f"Final converged score: {final_score:.3f}",
            f"Recursion depth achieved: {len(self.recursion_history)}",
            "",
            "Refinement History:"
        ]
        
        for entry in self.recursion_history:
            report_lines.append(f"\nDepth {entry['depth']} (K{entry['scale']} focus):")
            report_lines.append(f"Problem: {entry['problem'][:200]}..." if len(entry['problem']) > 200 else f"Problem: {entry['problem']}")
            report_lines.append(f"Score: {entry['score']:.3f}")
            report_lines.append("─" * 40)
            report_lines.append(entry['solution'])
            report_lines.append("=" * 60)
        
        full_report = "\n".join(report_lines)
        logger.info("Recursive solution process completed.")
        return full_report

# Example usage (for testing; can be removed in production).
if __name__ == "__main__":
    problems = [
        "Design the foundation for a sustainable planetary civilization.",
        "Harness stellar energy at maximum theoretical efficiency.",
        "Achieve stable universal constants across variants.",
        "Create the optimal multiversal infrastructure framework."
    ]
    
    for prob in problems:
        print(f"\nInitial Problem: {prob}")
        solver = RecursiveMultiversalSolver(prob, max_recursion_depth=3)
        solution = solver.process_problem()
        print(solution)