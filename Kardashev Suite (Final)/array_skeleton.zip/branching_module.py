# branching_module.py
# This module introduces branching and recombination of solution paths.
# It extends SelectiveMultiversalSolver by allowing multiple independent chains
# to be spawned at key decision points (specifically after K3 and K4 executions),
# simulating a multiversal civilization exploring parallel variants of solutions
# before selecting or recombining the most promising ones.
# Each branch runs a sub-chain from the branching point onward.
# Final solution recombines results from all branches, preserving the best aspects.
# This ties directly into the selective chaining framework without modifying prior modules.

import logging
import copy

from selection_module import SelectiveMultiversalSolver, logger

# Ensure logging consistency.
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

class BranchingMultiversalSolver(SelectiveMultiversalSolver):
    def __init__(self, problem_description):
        """
        Initialize the BranchingMultiversalSolver.
        
        :param problem_description: str - The problem to solve.
        """
        super().__init__(problem_description)
        self.branch_points = [3, 4]  # Kardashev scales after which we branch (K3 galactic, K4 universal).
        logger.info("BranchingMultiversalSolver initialized, adding multiversal branching capability.")

    def execute_chain_from(self, skeletons, start_index, initial_input):
        """
        Execute a chain starting from a given index in the skeleton list.
        Used for each branch.
        
        :param skeletons: list - Full list of selected skeletons.
        :param start_index: int - Index to start chaining from.
        :param initial_input: any - Input data at the branching point.
        :return: tuple - (branch_path_names, final_output)
        """
        input_data = initial_input
        branch_path = []
        results = []
        
        for skeleton in skeletons[start_index:]:
            output = skeleton.execute(input_data)
            results.append(output)
            branch_path.append(skeleton.name)
            input_data = output
            logger.info(f"Branch execution: {skeleton.name} -> {output}")
        
        branch_description = " -> ".join(branch_path)
        final_output = " -> ".join(results) if results else initial_input
        return branch_description, final_output

    def process_problem(self):
        """
        Override process_problem to implement branching.
        Runs the common chain up to each branch point, then spawns parallel variant chains
        from that point onward. Collects and recombines all branch outcomes.
        
        :return: str - The recombined multiversal solution.
        """
        self.sequence_array()
        selected_skeletons = self.select_right_skeletons()
        
        if not selected_skeletons:
            solution = "No skeletons selected for the given problem."
            logger.info(solution)
            return solution
        
        # Map scale to index for quick lookup.
        scale_to_index = {sk.scale: idx for idx, sk in enumerate(selected_skeletons)}
        
        # Find actual branch indices based on available scales.
        actual_branch_indices = []
        for bp in self.branch_points:
            if bp in scale_to_index:
                actual_branch_indices.append(scale_to_index[bp] + 1)  # Start after the branch point skeleton.
        
        logger.info(f"Branch points activated at indices: {actual_branch_indices}")
        
        input_data = self.problem_description
        common_results = []
        current_index = 0
        
        # Execute common prefix until first branch point.
        branches = []
        for i, skeleton in enumerate(selected_skeletons):
            output = skeleton.execute(input_data)
            common_results.append(output)
            input_data = output
            logger.info(f"Common chain: {skeleton.name} -> {output}")
            
            if i + 1 in actual_branch_indices:
                # Branch from here: remaining skeletons form variants.
                remaining_skeletons = selected_skeletons[i + 1:]
                if remaining_skeletons:
                    # Create multiple branches (here fixed at 3 for multiversal variants; expandable later).
                    for branch_id in range(1, 4):  # Three parallel universes/variants.
                        branch_desc, branch_out = self.execute_chain_from(
                            selected_skeletons, i + 1, output
                        )
                        branches.append(f"Variant {branch_id} [{branch_desc}]: {branch_out}")
                current_index = i + 1
        
        # Build final recombined solution.
        common_part = " -> ".join(common_results) if common_results else self.problem_description
        
        if branches:
            branches_part = " | ".join(branches)
            solution = f"Branching multiversal solution:\nCommon path: {common_part}\nParallel variants: {branches_part}"
        else:
            solution = f"Branching multiversal solution (no branches triggered): {common_part}"
        
        logger.info(f"Final recombined solution developed.")
        return solution

# Example usage (for testing; can be removed in production).
if __name__ == "__main__":
    problems = [
        "Design a sustainable multiversal civilization infrastructure.",
        "Explore consequences of altering universal constants.",
        "Optimize energy extraction across parallel realities.",
        "Simple planetary resource problem."  # Minimal branching
    ]
    
    for prob in problems:
        print(f"\nProblem: {prob}")
        solver = BranchingMultiversalSolver(prob)
        solution = solver.process_problem()
        print(solution)