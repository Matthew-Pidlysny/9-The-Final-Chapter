# selection_module.py
# This module extends the framework by introducing intelligent skeleton selection.
# It subclasses ChainedMultiversalSolver to add a sophisticated select_right_skeletons method
# that analyzes the problem description and dynamically chooses the most appropriate
# skeletons from the array, rather than using all of them. This simulates a multiversal
# civilization efficiently allocating computational resources only where needed.
# Selection is based on keyword matching and scale relevance, with explicit rules
# that can be expanded in future modules (e.g., with ML-based classifiers).
# The chaining behavior from the previous module is preserved.

import logging
import re

from chaining_module import ChainedMultiversalSolver, logger

# Ensure logging consistency.
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

class SelectiveMultiversalSolver(ChainedMultiversalSolver):
    def __init__(self, problem_description):
        """
        Initialize the SelectiveMultiversalSolver.
        
        :param problem_description: str - The problem to solve.
        """
        super().__init__(problem_description)
        logger.info("SelectiveMultiversalSolver initialized, adding intelligent skeleton selection.")

    def analyze_problem_scale(self):
        """
        Analyze the problem description to estimate the required Kardashev scale.
        Uses keyword patterns to map the problem to one or more scales.
        Returns a set of required scale integers (1-5).
        This is fully declared and expandable.
        """
        problem = self.problem_description.lower()
        
        # Define keyword mappings for each scale (explicit and non-compact for future expansion).
        scale_keywords = {
            1: ["planet", "earth", "resource", "population", "climate", "ecosystem", "local", "city", "country"],
            2: ["star", "sun", "stellar", "fusion", "dysons", "dyson sphere", "energy harnessing", "solar system"],
            3: ["galaxy", "galactic", "interstellar", "black hole", "dark matter", "star cluster", "milky way"],
            4: ["universe", "cosmology", "big bang", "spacetime", "quantum gravity", "universal law", "cosmological constant"],
            5: ["multiverse", "many-worlds", "parallel universe", "branching", "reality selection", "variant", "eternal inflation"]
        }
        
        required_scales = set()
        
        for scale, keywords in scale_keywords.items():
            if any(re.search(r'\b' + re.escape(kw) + r'\b', problem) for kw in keywords):
                required_scales.add(scale)
                logger.info(f"Detected scale {scale} relevance via keywords: {keywords}")
        
        # If no specific keywords, default to progressive inclusion up to K5 (multiversal problems often span scales).
        if not required_scales:
            logger.info("No specific scale keywords detected; defaulting to full K1-K5 progression.")
            required_scales = {1, 2, 3, 4, 5}
        
        # Always include lower scales if a higher one is detected (build-up principle).
        max_detected = max(required_scales) if required_scales else 5
        required_scales = required_scales.union(range(1, max_detected + 1))
        
        logger.info(f"Analyzed required scales: {sorted(required_scales)}")
        return required_scales

    def select_right_skeletons(self):
        """
        Override to dynamically select skeletons based on problem analysis.
        Selects only those whose scale is in the required set.
        Preserves order by scale for proper chaining.
        
        :return: list - Selected SkeletonProcess instances.
        """
        required_scales = self.analyze_problem_scale()
        
        selected = [sk for sk in self.skeleton_array if sk.scale in required_scales]
        
        # Ensure selected are sorted by scale for meaningful chaining.
        selected.sort(key=lambda sk: sk.scale)
        
        logger.info(f"Selected {len(selected)} skeletons: {[sk.name for sk in selected]}")
        return selected

# Example usage (for testing; can be removed in production).
if __name__ == "__main__":
    problems = [
        "Optimize energy distribution on Earth.",
        "Design a Dyson sphere around a star.",
        "Simulate galactic collisions.",
        "Unify quantum mechanics and general relativity.",
        "Select the optimal branch in a multiversal inflation scenario.",
        "Solve for sustainable resource management."  # No strong keywords, triggers full chain
    ]
    
    for prob in problems:
        print(f"\nProblem: {prob}")
        solver = SelectiveMultiversalSolver(prob)
        solution = solver.process_problem()
        print(solution)