# chaining_module.py
# This module extends the base_module by providing a chained processing mechanism.
# It subclasses MultiversalSolver to override the process_problem method,
# changing from parallel execution to sequential chaining, where the output
# of one skeleton becomes the input to the next. This allows for progressive
# solution building, simulating how a multiversal civilization might iteratively
# refine solutions across scales. It ties directly into the base module without
# altering it, allowing for modular expansion. Future modules can further extend
# this or add alternative processing strategies.

import logging

from base_module import MultiversalSolver, logger  # Import the base class and logger.

# Configure logging if needed (already set in base, but ensure consistency).
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

class ChainedMultiversalSolver(MultiversalSolver):
    def __init__(self, problem_description):
        """
        Initialize the ChainedMultiversalSolver, inheriting from MultiversalSolver.
        
        :param problem_description: str - A description of the problem to solve.
        """
        super().__init__(problem_description)
        logger.info("ChainedMultiversalSolver initialized, extending base for sequential processing.")

    def process_problem(self):
        """
        Override the base process_problem to implement chaining.
        Sequences the skeletons, selects them, and executes sequentially,
        feeding the output of one into the next. Collects results and develops
        a chained solution. No multiprocessing is used here, as chaining requires
        sequential execution.
        
        :return: str - The developed chained solution.
        """
        self.sequence_array()
        selected_skeletons = self.select_right_skeletons()
        
        input_data = self.problem_description
        results = []
        
        for skeleton in selected_skeletons:
            output = skeleton.execute(input_data)
            results.append(output)
            input_data = output  # Chain the output to the next input.
            logger.info(f"Chained {skeleton.name} output: {output}")
        
        # Develop solution by joining the chained results.
        solution = "Chained multiversal solution: " + " -> ".join(results)
        logger.info(f"Developed chained solution: {solution}")
        return solution

# Example usage (for testing the module; can be removed in production).
if __name__ == "__main__":
    solver = ChainedMultiversalSolver("Solve for optimal multiversal energy distribution.")
    solution = solver.process_problem()
    print(solution)